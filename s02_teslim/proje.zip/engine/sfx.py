"""Matematik tabanlı ses efekti sentezi (müzik değil).
Kullanım: python3 sfx.py cues.json out.wav
Seviye: efektler konuşmanın çok altında (tepe ≈ -20 dBFS); render tarafında ayrıca sidechain ile kısılır.
"""
import json, sys
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io import wavfile

SR = 48000
LEVEL = 0.10  # gain=1 efektin tepe genliği
rng = np.random.default_rng(7)


def t_(d):
    return np.arange(int(d * SR)) / SR


def env(n, a, r, curve=4.0):
    """a: atak (sn), r: sönüm (sn) üstel"""
    t = np.arange(n) / SR
    e = np.minimum(1, t / max(a, 1e-4))
    return e * np.exp(-np.maximum(0, t - a) * curve / max(r, 1e-4))


def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], btype="band", fs=SR, output="sos"), x)


def lp(x, f, order=2):
    return sosfilt(butter(order, f, btype="low", fs=SR, output="sos"), x)


def hp(x, f, order=2):
    return sosfilt(butter(order, f, btype="high", fs=SR, output="sos"), x)


def noise(n):
    return rng.standard_normal(n)


def norm(x):
    m = np.max(np.abs(x)) + 1e-9
    return x / m


# ---------- efektler ----------
def whoosh(p):
    d = p.get("d", 1.2)
    n = int(d * SR)
    t = t_(d)
    shape = np.sin(np.pi * t / d) ** 2
    x = noise(n)
    # zamanla kayan bant geçiren: iki bandın karışımı
    lo = bp(x, 300, 1200) * (1 - t / d)
    hi = bp(x, 900, 3500) * (t / d)
    return norm((lo + hi) * shape) * 0.7


def swish(p):
    d = 0.45
    n = int(d * SR); t = t_(d)
    shape = np.sin(np.pi * t / d) ** 3
    return norm(bp(noise(n), 1500, 6000) * shape) * 0.6


def pen(p):
    d = p.get("d", 0.8)
    n = int(d * SR); t = t_(d)
    strokes = 0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 7 * t + 1.3 * np.sin(2 * np.pi * 2.1 * t)))
    grit = bp(noise(n), 2500, 7000) * (0.6 + 0.4 * rng.random(n))
    fade = np.minimum(1, t / 0.04) * np.minimum(1, (d - t) / 0.08)
    return norm(grit * lp(strokes, 60) * fade) * 0.55


def shimmer(p):
    f = p.get("f", 440)
    d = 2.6
    t = t_(d)
    x = np.zeros_like(t)
    for k, (m, a) in enumerate([(1, 1), (2, 0.35), (3.01, 0.18), (4.2, 0.08)]):
        x += a * np.sin(2 * np.pi * f * m * t + k) * (1 + 0.003 * np.sin(2 * np.pi * 5 * t))
    e = env(len(t), 0.25, d, 3.2)
    return norm(x * e) * 0.45


def tick(p):
    f = p.get("f", 1800)
    d = 0.06
    t = t_(d)
    x = np.sin(2 * np.pi * f * t) * env(len(t), 0.001, 0.03, 5) + 0.3 * hp(noise(len(t)), 3000) * env(len(t), 0.0005, 0.008, 5)
    return norm(x) * 0.5


def blip(p):
    f = p.get("f", 880)
    d = 0.22
    t = t_(d)
    x = np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * f * 2 * t)
    return norm(x * env(len(t), 0.004, 0.18, 5)) * 0.45


def step(p):
    d = 0.18
    t = t_(d)
    body = np.sin(2 * np.pi * (90 - 40 * t / d) * t) * env(len(t), 0.003, 0.12, 6)
    scuff = bp(noise(len(t)), 400, 1500) * env(len(t), 0.002, 0.05, 6) * 0.4
    return norm(body + scuff) * 0.6


def thump(p):
    d = 0.4
    t = t_(d)
    f = 70 * np.exp(-t * 6) + 45
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.002, 0.3, 5)
    slap = lp(noise(len(t)), 900) * env(len(t), 0.001, 0.04, 6) * 0.5
    return norm(body + slap)


def hit(p):
    d = 2.2
    t = t_(d)
    f = 110 * np.exp(-t * 3) + 38
    sub = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.004, 1.6, 3.5)
    air = lp(noise(len(t)), 2500) * env(len(t), 0.002, 0.5, 5) * 0.25
    return norm(sub + air) * 0.85


def fall(p):
    d = 1.4
    t = t_(d)
    f = 520 * np.exp(-t * 1.6) + 120
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.05, d, 2.5)
    return norm(x) * 0.35


def thunk(p):
    d = 0.5
    t = t_(d)
    body = np.sin(2 * np.pi * 150 * t) * env(len(t), 0.002, 0.25, 6)
    wood = bp(noise(len(t)), 300, 1200) * env(len(t), 0.001, 0.06, 6) * 0.7
    return norm(body + wood) * 0.7


def door(p):
    d = 0.9
    t = t_(d)
    creak = bp(noise(len(t)), 600, 1400) * np.sin(2 * np.pi * 9 * t) ** 2 * np.minimum(1, t / 0.2) * (t < 0.45)
    slam = np.zeros_like(t)
    i = int(0.42 * SR)
    m = len(t) - i
    tt = np.arange(m) / SR
    slam[i:] = np.sin(2 * np.pi * 80 * tt) * np.exp(-tt * 9) + lp(noise(m), 1200) * np.exp(-tt * 25) * 0.6
    return norm(creak * 0.25 + slam) * 0.8


def click(p):
    d = 0.08
    t = t_(d)
    x = hp(noise(len(t)), 2000) * env(len(t), 0.0005, 0.01, 6) + np.sin(2 * np.pi * 2400 * t) * env(len(t), 0.0005, 0.02, 6) * 0.5
    return norm(x) * 0.6


def riser(p):
    d = p.get("d", 2.4)
    t = t_(d)
    f = 80 * (1 + 2.5 * (t / d) ** 2)
    tone = np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.4 * np.sin(2 * np.pi * np.cumsum(f * 1.5) / SR)
    air = bp(noise(len(t)), 500, 3000) * (t / d) ** 2 * 0.4
    e = (t / d) ** 1.5 * np.minimum(1, (d - t) / 0.15)
    return norm((tone * 0.6 + air) * e) * 0.5


def room(p):
    """Oda tonu: çok düşük, yavaş dalgalanan koyu gürültü"""
    d = p.get("d", 60)
    n = int(d * SR)
    t = np.arange(n) / SR
    x = lp(noise(n), 220, 4) + 0.3 * bp(noise(n), 2000, 5000)
    x = x * (0.8 + 0.2 * np.sin(2 * np.pi * 0.07 * t))
    x = norm(x) * 0.09
    fade = np.minimum(1, t / 1.5) * np.minimum(1, (d - t) / 1.5)
    return x * fade


FX = dict(whoosh=whoosh, swish=swish, pen=pen, shimmer=shimmer, tick=tick, blip=blip, step=step, thump=thump,
          hit=hit, fall=fall, thunk=thunk, door=door, click=click, riser=riser, room=room)


def main():
    cfg = json.load(open(sys.argv[1]))
    D = cfg["duration"]
    n = int((D + 3) * SR)
    L = np.zeros(n); R = np.zeros(n)
    dry_room = np.zeros(n)
    for c in cfg["cues"]:
        fn = FX.get(c["type"])
        if not fn:
            print("bilinmeyen efekt:", c["type"]); continue
        x = fn(c.get("p") or {}) * c.get("gain", 1) * LEVEL
        i = int(c["t"] * SR)
        x = x[: max(0, n - i)]
        if c["type"] == "room":
            dry_room[i:i + len(x)] += x
            continue
        pan = np.sin(c["t"] * 1.7) * 0.25  # hafif stereo çeşitlilik
        L[i:i + len(x)] += x * (1 - pan)
        R[i:i + len(x)] += x * (1 + pan)
    # kısa oda yankısı
    ir_t = np.arange(int(0.9 * SR)) / SR
    irL = noise(len(ir_t)) * np.exp(-ir_t * 6); irR = noise(len(ir_t)) * np.exp(-ir_t * 6)
    irL /= np.sqrt(np.sum(irL ** 2)); irR /= np.sqrt(np.sum(irR ** 2))
    L = L + 0.22 * fftconvolve(L, irL)[:n]
    R = R + 0.22 * fftconvolve(R, irR)[:n]
    L += dry_room; R += dry_room
    out = np.stack([L, R], 1)[: int(D * SR)]
    peak = np.max(np.abs(out))
    if peak > 0.3:
        out *= 0.3 / peak
    wavfile.write(sys.argv[2], SR, (out * 32767).astype(np.int16))
    print(f"sfx ok: {len(cfg['cues'])} efekt, tepe {20*np.log10(np.max(np.abs(out))+1e-9):.1f} dBFS")


main()
