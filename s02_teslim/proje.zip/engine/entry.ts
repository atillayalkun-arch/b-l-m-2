// Tarayıcı tarafı: bölümü canvas'a çizer, render betiğine kare verir.
import { W, H, Section } from "./core";
import { s01 } from "../sections/s01";
import { s02 } from "../sections/s02";

const SECTIONS: Record<string, Section> = { s01, s02 };

declare global { interface Window { __init: (id: string) => Promise<any>; __frames: (ts: number[], q: number) => string[] } }

let sec: Section;
const canvas = document.createElement("canvas");
canvas.width = W; canvas.height = H;
document.body.appendChild(canvas);
const ctx = canvas.getContext("2d")!;

window.__init = async (id: string) => {
  sec = SECTIONS[id];
  // fontlar yüklenmeden çizim yok
  const probe = "思い出されるのは誰か思考実験顕著性効果上司席報告評価記憶冒頭非注意性盲目評価記憶あいう0123456789%";
  await Promise.all([
    document.fonts.load(`400 40px "Noto Sans CJK JP"`, probe),
    document.fonts.load(`500 40px "Noto Sans CJK JP"`, probe),
    document.fonts.load(`700 40px "Noto Sans CJK JP"`, probe),
    document.fonts.load(`600 40px "Noto Serif CJK JP"`, probe),
    document.fonts.load(`700 40px "Noto Serif CJK JP"`, probe),
    document.fonts.load(`500 40px "Noto Sans JP"`, probe),
    document.fonts.load(`700 40px "Noto Serif JP"`, probe),
  ]);
  return { duration: sec.duration, cues: sec.cues, parts: sec.parts.map((p) => ({ audio: p.timing.audio, at: p.at })) };
};

window.__frames = (ts: number[], q: number) =>
  ts.map((t) => { sec.draw(ctx, t); return canvas.toDataURL("image/jpeg", q); });
