# Kendi bilgisayarında render (Windows)

## Bir kerelik kurulum
1. **Node.js 20+** → https://nodejs.org (LTS)
2. **FFmpeg** → PowerShell: `winget install Gyan.FFmpeg` (sonra terminali kapatıp aç)
3. **Python 3** → https://python.org (kurulumda "Add to PATH" işaretle), sonra: `pip install numpy scipy`
4. **Fontlar** → Google Fonts'tan **Noto Sans JP** ve **Noto Serif JP** indir, tüm ağırlıkları "Tüm kullanıcılar için yükle".
5. Proje klasöründe (proje.zip'i açtığın yer):
   ```
   npm install
   npx playwright install chromium
   ```

## Render
1. Ses dosyalarını `audio/` klasörüne koy (s01 için 1.mp3, 2.mp3, 3.mp3).
2. Proje klasöründe:
   ```
   node engine/render_all.mjs s01
   ```
3. Sonuç: `out/s01.mp4` (görüntü + seslendirme + efektler).

- Kesilirse aynı komutu tekrar çalıştır, kaldığı yerden devam eder.
- Tek kare kontrolü: `node engine/render.mjs s01 --stills 10,45.5` → `out/stills/`
