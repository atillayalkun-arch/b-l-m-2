// s05 見てる人は見てる？ — ses 10, 11  (s03/s04 yapısı: SCENES + lens + cues)
// Yeni ortak parçalar: components/voices.ts (hangingScroll, sumiHawk, sumiFloor, hanko, chatBubble, typingDots,
// phone, spotlight, figureIcon) · components/cards.ts → statPair().
import { Section, Part, Cue, W, H, clamp, ease, prog, win, lerp, rnd } from "../engine/core";
import { C, font, lightPool, fadeBlack, rr, dust, boardGrid } from "../design/style";
import { lens, LENS, cam, dof, Lens, bokeh } from "../design/grade";
import { envOffice, officeDesk } from "../design/env";
import { smoke, whipStreaks, flashPop } from "../design/fx";
import { drawPerson } from "../characters/people";
import { mug, plant, wallClock } from "../characters/props";
import { sectionTitle, sourceCard, boardLabel, statPair } from "../components/cards";
import { hangingScroll, sumiHawk, sumiFloor, hanko, chatBubble, typingDots, phone, spotlight, figureIcon } from "../components/voices";
import { drawSubtitles } from "../components/subtitle";
import t10 from "../timing/10.json";
import t11 from "../timing/11.json";

const P10: Part = { timing: t10 as any, at: 3.4 };
const P11: Part = { timing: t11 as any, at: 58.4 };
const parts = [P10, P11];
const END = P11.at + 27.64 + 2.2;
const g10 = (l: number) => P10.at + l;
const g11 = (l: number) => P11.at + l;
const CARD_A = g10(51.25), CARD_B = P11.at - 0.15; // 58.6% / 32.3% kartı
// NOT: anket kaynağı senaryoda verilmediyse burada düzeltin
const SRC = "ビジネスパーソン調査（自己アピールに関する意識）";
type Ctx = CanvasRenderingContext2D;

function layer(ctx: Ctx, a: number, fn: () => void) {
  if (a <= 0.001) return;
  ctx.save(); ctx.globalAlpha *= clamp(a); fn(); ctx.restore();
}
const breathe = (t: number, i = 0) => Math.sin(t * 1.6 + i * 1.3) * 2;

const LENS_WASHI: Lens = { shadow: "rgba(20,44,58,0.30)", high: "rgba(255,170,90,0.16)", bloom: 0.75, ca: 0.6, vig: 0.8, grain: 0.07, exposure: 1.0, sat: 0.92 };
const LENS_SCREEN: Lens = { shadow: "rgba(10,50,72,0.36)", high: "rgba(150,210,255,0.10)", bloom: 0.8, ca: 1.2, vig: 0.74, grain: 0.06, exposure: 1.0, sat: 0.9 };
const LENS_STAGE: Lens = { shadow: "rgba(16,40,62,0.34)", high: "rgba(255,200,130,0.14)", bloom: 0.9, ca: 1.0, vig: 0.82, grain: 0.065, exposure: 1.0, sat: 0.9 };

// ================= ortak set parçaları =================
/** 土壁 (toprak sıva duvar) + ahşap kirişler */
function earthWall(c: Ctx, x0: number, x1: number, y0: number, y1: number, warm = 1, seed = 0) {
  const g = c.createLinearGradient(0, y0, 0, y1);
  g.addColorStop(0, `rgb(${Math.round(58 * warm + 20)},${Math.round(46 * warm + 18)},${Math.round(34 * warm + 16)})`);
  g.addColorStop(1, `rgb(${Math.round(38 * warm + 14)},${Math.round(30 * warm + 13)},${Math.round(24 * warm + 12)})`);
  c.fillStyle = g; c.fillRect(x0, y0, x1 - x0, y1 - y0);
  c.fillStyle = "rgba(255,230,190,0.04)";
  for (let i = 0; i < 160; i++) c.fillRect(x0 + rnd(i, seed + 11) * (x1 - x0), y0 + rnd(i, seed + 12) * (y1 - y0), 2 + rnd(i, seed + 13) * 5, 2);
  c.fillStyle = "rgba(0,0,0,0.06)";
  for (let i = 0; i < 120; i++) c.fillRect(x0 + rnd(i, seed + 14) * (x1 - x0), y0 + rnd(i, seed + 15) * (y1 - y0), 3, 1 + rnd(i, seed + 16) * 3);
}
function beam(c: Ctx, x: number, y0: number, y1: number, w = 46) {
  const g = c.createLinearGradient(x - w / 2, 0, x + w / 2, 0);
  g.addColorStop(0, "#2A1C12"); g.addColorStop(0.4, "#4A3220"); g.addColorStop(1, "#22170F");
  c.fillStyle = g; c.fillRect(x - w / 2, y0, w, y1 - y0);
  c.strokeStyle = "rgba(0,0,0,0.25)"; c.lineWidth = 1.5;
  for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(x - w / 2 + 8 + i * 9, y0); c.lineTo(x - w / 2 + 10 + i * 9, y1); c.stroke(); }
}
/** Şamdan + titreyen mum */
function candle(c: Ctx, t: number, x: number, y: number, s: number, seed = 0) {
  c.save(); c.translate(x, y); c.scale(s, s);
  c.fillStyle = "#1E1812"; c.fillRect(-26, -8, 52, 8); c.fillRect(-5, -80, 10, 74); c.fillRect(-18, -88, 36, 8);
  c.fillStyle = "#E8DEC6"; rr(c, -9, -150, 18, 64, 3); c.fill();
  const f = 1 + Math.sin(t * 13 + seed) * 0.08 + Math.sin(t * 29 + seed) * 0.05, sw = Math.sin(t * 3.1 + seed) * 2;
  c.fillStyle = "rgba(255,170,70,0.9)"; c.beginPath(); c.ellipse(sw, -164, 6, 15 * f, 0, 0, Math.PI * 2); c.fill();
  c.fillStyle = "rgba(255,240,200,0.95)"; c.beginPath(); c.ellipse(sw * 0.6, -160, 3, 7 * f, 0, 0, Math.PI * 2); c.fill();
  c.restore();
  lightPool(c, x, y - 164 * s, 220 * s, "rgba(255,190,110,", 0.32 * (0.9 + 0.1 * Math.sin(t * 13 + seed)));
}

// ================= A: 和室 — 黙って支える人をたたえる言葉 =================
function sceneStudy(c: Ctx, t: number) {
  const l = t - P10.at;
  const k = ease.inOut(prog(l, -0.8, 5.2));
  const lamp = ease.out(prog(l, 0.15, 0.9));
  c.save();
  cam(c, t, lerp(1.0, 1.16, k), lerp(60, -40, k), lerp(30, -20, k), 0.5, 960, 640);
  // arka: shoji (arkadan sıcak ışık), tokonoma
  dof(c, 3.5, () => {
    c.fillStyle = "#1A140F"; c.fillRect(-400, -300, W + 800, 1000);
    const sx0 = 640, sx1 = 2100;
    const sg = c.createLinearGradient(0, 60, 0, 640);
    sg.addColorStop(0, `rgba(230,200,150,${0.35 + 0.35 * lamp})`); sg.addColorStop(1, `rgba(150,120,90,${0.25 + 0.25 * lamp})`);
    c.fillStyle = sg; c.fillRect(sx0, 60, sx1 - sx0, 580);
    // shoji gölgeleri: üç rulo (いくつも)
    for (let i = 0; i < 3; i++) {
      const a = ease.out(prog(l, 3.7 + i * 0.22, 4.3 + i * 0.22));
      c.fillStyle = `rgba(30,22,14,${0.42 * a})`; c.fillRect(840 + i * 300, 120, 120, 380 * a);
      c.fillRect(828 + i * 300, 112, 144, 10 * a);
    }
    c.strokeStyle = "#2A1D13"; c.lineWidth = 7;
    for (let x = sx0; x <= sx1; x += 120) { c.beginPath(); c.moveTo(x, 60); c.lineTo(x, 640); c.stroke(); }
    for (let y = 60; y <= 640; y += 96) { c.beginPath(); c.moveTo(sx0, y); c.lineTo(sx1, y); c.stroke(); }
    c.fillStyle = "#24180F"; c.fillRect(sx0 - 30, 30, sx1 - sx0 + 60, 34); c.fillRect(sx0 - 30, 636, sx1 - sx0 + 60, 26);
    // tokonoma + vazo + çiçek dalı
    earthWall(c, 40, 600, 60, 640, 0.8, 3);
    c.fillStyle = "#2E2117"; c.fillRect(40, 600, 560, 40);
    c.fillStyle = "#3C4A52"; c.beginPath(); c.ellipse(320, 560, 40, 46, 0, 0, Math.PI * 2); c.fill(); c.fillRect(304, 500, 32, 30);
    c.strokeStyle = "#3A2A1C"; c.lineWidth = 4; c.beginPath(); c.moveTo(320, 500); c.quadraticCurveTo(300, 380, 380, 300); c.moveTo(330, 420); c.quadraticCurveTo(400, 400, 430, 350); c.stroke();
    for (let i = 0; i < 7; i++) { c.fillStyle = "rgba(220,170,170,0.8)"; c.beginPath(); c.arc(330 + rnd(i, 7) * 100, 300 + rnd(i, 8) * 110, 8, 0, Math.PI * 2); c.fill(); }
    beam(c, 620, -300, 700, 50); beam(c, 20, -300, 700, 50);
  });
  // tatami zemin
  const fg = c.createLinearGradient(0, 640, 0, H + 200);
  fg.addColorStop(0, "#5A5638"); fg.addColorStop(1, "#2C2A1C");
  c.fillStyle = fg; c.fillRect(-400, 640, W + 800, 800);
  c.strokeStyle = "rgba(20,18,10,0.35)"; c.lineWidth = 2;
  for (let i = -10; i < 30; i++) { c.beginPath(); c.moveTo(960 + i * 40, 640); c.lineTo(960 + i * 110, H + 200); c.stroke(); }
  c.fillStyle = "#1E2A22"; c.fillRect(-400, 880, W + 800, 16); // tatami kenar şeridi
  // andon (sağ)
  c.save(); c.translate(1560, 760);
  c.fillStyle = "#24180F"; c.fillRect(-60, -10, 120, 14); c.fillRect(-56, -250, 8, 240); c.fillRect(48, -250, 8, 240);
  c.fillStyle = `rgba(240,210,160,${0.45 + 0.5 * lamp})`; c.fillRect(-48, -240, 96, 210);
  c.strokeStyle = "#24180F"; c.lineWidth = 3; c.strokeRect(-48, -240, 96, 105); c.strokeRect(-48, -135, 96, 105);
  c.restore();
  lightPool(c, 1560, 640, 520, "rgba(255,196,120,", 0.38 * lamp * (0.95 + 0.05 * Math.sin(t * 9)));
  // fuzukue (alçak yazı masası)
  c.fillStyle = "rgba(0,0,0,0.4)"; c.beginPath(); c.ellipse(900, 900, 520, 40, 0, 0, Math.PI * 2); c.fill();
  c.fillStyle = "#5A3A24"; c.fillRect(400, 720, 1000, 30); c.fillStyle = "#3A2616"; c.fillRect(400, 750, 1000, 14);
  c.fillRect(430, 764, 26, 130); c.fillRect(1344, 764, 26, 130);
  // washi + yazılan 言葉
  c.save(); c.translate(860, 716); c.scale(1, 0.42);
  c.fillStyle = "#B9AE94"; c.fillRect(-200, -280, 400, 280); c.fillStyle = "rgba(0,0,0,0.12)"; c.fillRect(-200, -280, 400, 30);
  c.restore();
  const wr = prog(l, 2.5, 3.8);
  c.save(); c.translate(860, 660); c.scale(1, 0.55);
  c.font = font(700, 96, true); c.textAlign = "center"; c.fillStyle = "#16120E";
  c.beginPath(); c.rect(-200, -120, 400 * wr, 200); c.clip();
  c.fillText("言葉", 0, 30); c.restore();
  // suzuri (mürekkep taşı) + damla halkası
  c.fillStyle = "#15161A"; rr(c, 1120, 690, 150, 36, 8); c.fill();
  c.fillStyle = "#08090B"; c.beginPath(); c.ellipse(1240, 704, 22, 8, 0, 0, Math.PI * 2); c.fill();
  const dp = prog(l, 1.55, 2.4);
  if (dp > 0 && dp < 1) { c.strokeStyle = `rgba(200,210,230,${0.6 * (1 - dp)})`; c.lineWidth = 2; c.beginPath(); c.ellipse(1240, 704, 6 + dp * 22, 2 + dp * 8, 0, 0, Math.PI * 2); c.stroke(); }
  // fırça: masadan kalkar → mürekkebe batar → yazar
  let bx = 1060, by = 710, ba = 1.45;
  const up = ease.inOut(prog(l, 1.2, 1.55)), dip = ease.inOut(prog(l, 1.55, 2.0)), wri = prog(l, 2.4, 3.8), back = ease.inOut(prog(l, 4.0, 4.6));
  if (l > 1.2) { bx = lerp(1060, 1240, up); by = lerp(710, 640, up) + 50 * Math.sin(dip * Math.PI); ba = lerp(1.45, 0.25, up); }
  if (l > 2.0) { const ww = ease.inOut(clamp(wri)); bx = lerp(1240, 760 + ww * 200, ease.inOut(prog(l, 2.0, 2.45))); by = lerp(640, 650 + Math.sin(ww * 30) * 14, ease.inOut(prog(l, 2.0, 2.45))); }
  if (l > 4.0) { bx = lerp(bx, 1060, back); by = lerp(by, 710, back); ba = lerp(0.25, 1.45, back); }
  c.save(); c.translate(bx, by); c.rotate(ba);
  c.fillStyle = "#6A4A2A"; rr(c, -6, -210, 12, 190, 5); c.fill();
  c.fillStyle = "#2A2420"; c.fillRect(-7, -26, 14, 12);
  c.fillStyle = "#121010"; c.beginPath(); c.moveTo(-8, -14); c.quadraticCurveTo(-6, 18, 0, 30); c.quadraticCurveTo(6, 18, 8, -14); c.fill();
  c.restore();
  // fırçalık
  c.fillStyle = "#2E3A40"; c.fillRect(1010, 710, 100, 12);
  c.restore();
  // ön plan: çay fincanı + buhar (DOF)
  dof(c, 7, () => {
    c.save(); c.translate(330 - k * 60, 1000);
    c.fillStyle = "#3A4A3E"; c.beginPath(); c.moveTo(-70, -120); c.lineTo(70, -120); c.lineTo(56, 0); c.lineTo(-56, 0); c.closePath(); c.fill();
    c.fillStyle = "#283228"; c.beginPath(); c.ellipse(0, -120, 70, 16, 0, 0, Math.PI * 2); c.fill();
    c.restore();
    smoke(c, t, 330 - k * 60, 860, 30, 200, 0.25, 4, 8, "220,220,215");
  });
  dust(c, t, 40, 0.28, 51);
}

// ================= B: 三つの掛け軸 — ことわざ =================
const SCR = [
  { x: 520, text: "縁の下の力持ち", un: 4.8, rv: [5.42, 6.82] },
  { x: 1320, text: "不言実行", un: 6.95, rv: [7.48, 8.48] },
  { x: 2120, text: "能ある鷹は爪を隠す", un: 8.75, rv: [9.26, 10.84] },
];
function sceneScrolls(c: Ctx, t: number) {
  const l = t - P10.at;
  const wOut = ease.in(prog(l, 11.6, 12.3));
  // kamera: sıradaki ruloyu kadraja alır (sürekli pan)
  const fx = l < 7.2 ? lerp(SCR[0].x, SCR[1].x, ease.inOut(prog(l, 6.4, 7.4))) : lerp(SCR[1].x, SCR[2].x, ease.inOut(prog(l, 8.3, 9.3)));
  const fx2 = lerp(fx, SCR[2].x + 120, ease.inOut(prog(l, 10.6, 11.8)));
  const zoom = lerp(1.06, 1.0, ease.inOut(prog(l, 4.4, 6.0))) + 0.04 * ease.inOut(prog(l, 10.0, 11.6));
  c.save();
  dof(c, wOut * 16, () => {
    c.save();
    cam(c, t, zoom, 960 - fx2 + 140 - wOut * 1800, 0, 0.45, 960, 540);
    earthWall(c, -1400, 3000, -200, 800, 1, 21);
    c.fillStyle = "#24180F"; c.fillRect(-1400, 40, 4400, 30); // nageshi
    for (const bx of [-700, -60, 920, 1720, 2620]) beam(c, bx, -200, 860, 54);
    c.fillStyle = "#2A2016"; c.fillRect(-1400, 800, 4400, 300);
    c.fillStyle = "#3C2E20"; c.fillRect(-1400, 800, 4400, 18);
    SCR.forEach((s, i) => {
      const on = 1 - 0.35 * (1 - win(l, s.un - 0.3, s.rv[1] + 1.2, 0.6));
      hangingScroll(c, t, s.x, 110, 230, 660, { text: s.text, unroll: prog(l, s.un, s.un + 0.6), reveal: prog(l, s.rv[0], s.rv[1]), seed: i * 2, glow: on - 0.65, dim: 0.35 * (1 - on) });
    });
    // 縁の下: sumi-e kesit (yan duvara asılı shikishi)
    shikishi(c, SCR[0].x + 290, 380, 1, ease.out(prog(l, 5.7, 6.4)), (cc) => sumiFloor(cc, 0, 10, 0.9, 1, Math.max(0, Math.sin(t * 4)) * 4 * prog(l, 6.0, 6.8)));
    // 不言実行: hanko vurulur
    hanko(c, SCR[1].x + 50, 700, 1, prog(l, 8.55, 8.95), "実");
    // 鷹: shikishi üstünde, pençe gizlenir @隠す
    shikishi(c, SCR[2].x + 300, 380, 1, ease.out(prog(l, 9.6, 10.2)), (cc) => sumiHawk(cc, 0, 0, 0.75, 1, ease.inOut(prog(l, 10.55, 11.0)), Math.max(0, Math.sin((l - 9.9) * 6)) * (1 - prog(l, 10.4, 10.9))));
    // tütsü + mum (set objesi)
    candle(c, t, SCR[1].x - 300, 800, 1.0, 1);
    smoke(c, t, SCR[1].x + 330, 780, 14, 360, 0.3, 9, 10, "200,200,195");
    c.fillStyle = "#3A2A1C"; c.fillRect(SCR[1].x + 300, 780, 60, 20);
    c.restore();
  });
  // ön plan kolon (parallax, DOF)
  dof(c, 9, () => {
    const px = 1500 - (fx2 - SCR[0].x) * 1.5 - wOut * 2600;
    beam(c, px, -100, H + 100, 120);
    beam(c, px + 1500, -100, H + 100, 120);
  });
  c.restore();
}
function shikishi(c: Ctx, x: number, y: number, s: number, k: number, art: (c: Ctx) => void) {
  if (k <= 0) return;
  c.save(); c.translate(x, y); c.scale(s, s); c.globalAlpha *= clamp(k);
  c.fillStyle = "rgba(0,0,0,0.35)"; c.fillRect(-110, -110, 236, 236);
  c.fillStyle = "#C8A060"; c.fillRect(-120, -120, 240, 240);
  c.fillStyle = "#E6DCC2"; c.fillRect(-110, -110, 220, 220);
  art(c);
  c.restore();
}

// ================= C: 職場の言葉 — チャット画面 =================
const FEED = [
  { at: 16.52, txt: "アピールしないと評価されない", who: "先輩", av: "#6A4E8A" },
  { at: 19.16, txt: "声が大きい人が得をする", who: "同期", av: "#3E7A8A" },
  { at: 22.04, txt: "アピールしたもん勝ち", who: "友人", av: "#8A5A3E" },
];
function sceneFeed(c: Ctx, t: number) {
  const l = t - P10.at;
  const wIn = 1 - ease.out(prog(l, 11.9, 12.5));
  const k = ease.inOut(prog(l, 12.0, 24.8));
  c.save();
  dof(c, wIn * 18, () => {
    c.save();
    cam(c, t, lerp(1.0, 1.1, k), wIn * 1800 + lerp(40, -30, k), lerp(10, -10, k), 0.5, 1000, 460);
    envOffice(c, t, 4, -l * 8);
    // arka: cam bölme arkasında 声が大きい人 (meyafon yok: el kol hareketi + ses halkaları)
    const loud = win(l, 19.0, 24.6, 0.5);
    dof(c, lerp(5, 2, loud), () => {
      c.fillStyle = "rgba(120,150,180,0.06)"; c.fillRect(-200, 250, 640, 520);
      drawPerson(c, 180, 760, 0.8, { outfit: 3, pose: "stand", armUp: 0.4 + 0.6 * loud * Math.max(0, Math.sin(t * 5)), rim: 0.7, rimSide: 1, facing: 0.5, bob: breathe(t) });
      [40, 330].forEach((x, i) => drawPerson(c, x, 770, 0.72, { outfit: i ? 1 : 4, pose: "stand", facing: lerp(0.3, x < 180 ? 0.8 : -0.8, loud), shade: 0.5, bob: breathe(t, i + 2) }));
      for (let i = 0; i < 3; i++) {
        const ph = (t * 1.2 + i / 3) % 1;
        c.strokeStyle = `rgba(240,200,140,${0.45 * (1 - ph) * loud})`; c.lineWidth = 3;
        c.beginPath(); c.arc(200, 560, 30 + ph * 200, -0.9, 0.9); c.stroke();
      }
    });
    // monitör (büyük, sohbet uygulaması)
    c.fillStyle = "rgba(0,0,0,0.5)"; rr(c, 560, 170, 1060, 640, 18); c.fill();
    c.fillStyle = "#101216"; rr(c, 540, 150, 1060, 640, 18); c.fill();
    const sg = c.createLinearGradient(0, 170, 0, 770);
    sg.addColorStop(0, "#151C26"); sg.addColorStop(1, "#0F141B");
    c.fillStyle = sg; c.fillRect(564, 172, 1012, 596);
    c.fillStyle = "#1C2531"; c.fillRect(564, 172, 1012, 56);
    c.fillStyle = "#C8D2E0"; c.font = font(600, 24); c.textAlign = "left"; c.fillText("# 雑談", 596, 210);
    c.fillStyle = "rgba(200,210,225,0.4)"; c.font = font(400, 20); c.fillText("メンバー 12", 1440, 210);
    c.fillStyle = "#18202B"; c.fillRect(564, 172, 150, 596);
    for (let i = 0; i < 7; i++) { c.fillStyle = i === 2 ? "rgba(140,190,240,0.5)" : "rgba(160,175,195,0.18)"; rr(c, 584, 260 + i * 46, 110, 20, 6); c.fill(); }
    // sohbet akışı: yeni balon geldikçe eskiler yukarı kayar
    c.save(); c.beginPath(); c.rect(714, 228, 862, 540); c.clip();
    let shift = 0; FEED.forEach((f) => { shift += 130 * ease.inOut(prog(l, f.at - 0.25, f.at + 0.15)); });
    c.translate(0, -shift);
    // önceki eski mesajlar
    [["今日の会議おつかれ", 0], ["資料ありがとう！", 1]].forEach(([s, i]) => chatBubble(c, (i as number) ? 1500 : 800, 330 + (i as number) * 120, s as string, 1, { side: (i as number) ? 1 : -1, size: 30, who: (i as number) ? "" : "後輩", avatar: "#5A6B4A", time: "21:4" + (i as number) }));
    c.translate(0, 0);
    typingDots(c, t, 760, 580, win(l, 14.7, 16.45, 0.15));
    FEED.forEach((f, i) => {
      const y = 580 + i * 130;
      if (i === 0) layer(c, 1, () => {}) ;
      chatBubble(c, 800, y, f.txt, prog(l, f.at - 0.2, f.at + 0.35), { side: -1, size: 40, who: f.who, avatar: f.av, time: `21:5${i}`, hot: win(l, f.at, f.at + 1.6, 0.3) });
      if (i < 2) typingDots(c, t, 760, y + 130, win(l, f.at + 1.1, FEED[i + 1].at - 0.25, 0.15));
    });
    // 👍 tepkileri (sayı artar)
    FEED.forEach((f, i) => {
      const n = Math.floor(clamp(prog(l, f.at + 0.6, f.at + 2.2)) * (5 + i * 4));
      if (n > 0) { const y = 580 + i * 130 + 92; c.fillStyle = "rgba(60,80,110,0.9)"; rr(c, 800, y, 92, 34, 17); c.fill(); c.fillStyle = "#E8EEF6"; c.font = font(600, 20); c.textAlign = "left"; c.fillText(`＋ ${n}`, 816, y + 24); }
    });
    // kupa ikonu (もん勝ち)
    const tr = ease.back(prog(l, 22.5, 23.0));
    if (tr > 0) {
      c.save(); c.translate(1380, 580 + 260 + 30); c.scale(tr, tr);
      c.fillStyle = "#D8A93A"; c.beginPath(); c.moveTo(-30, -40); c.lineTo(30, -40); c.quadraticCurveTo(28, 10, 0, 16); c.quadraticCurveTo(-28, 10, -30, -40); c.fill();
      c.fillRect(-5, 14, 10, 18); c.fillRect(-20, 30, 40, 8);
      c.strokeStyle = "#D8A93A"; c.lineWidth = 5; c.beginPath(); c.arc(-30, -24, 12, Math.PI * 0.5, Math.PI * 1.5); c.arc(30, -24, 12, -Math.PI * 0.5, Math.PI * 0.5); c.stroke();
      c.restore();
      flashPop(c, 1380, 860 - shift * 0, Math.max(0, 1 - prog(l, 22.5, 23.2)) * 0.6);
    }
    c.restore();
    // monitör ayağı + masa
    c.fillStyle = "#1A1C20"; c.fillRect(1040, 790, 60, 70); c.fillRect(960, 856, 220, 14);
    c.fillStyle = "#4A3424"; c.fillRect(-200, 870, W + 400, 30); c.fillStyle = "#2A1D13"; c.fillRect(-200, 900, W + 400, 300);
    c.fillStyle = "#1C1F25"; rr(c, 760, 884, 520, 26, 6); c.fill(); // klavye
    c.restore();
  });
  // ön plan: masadaki telefon her mesajda titrer (DOF)
  dof(c, 3 + wIn * 14, () => {
    const bz = FEED.reduce((a, f) => a + win(l, f.at, f.at + 0.5, 0.05), 0);
    phone(c, t, 1640 + wIn * 2000, 960, 1.15, { rot: 1.35, glow: 0.3 + 0.7 * clamp(bz + 0.2 * win(l, 14.7, 24.6, 0.3)), buzz: bz, content: (cc) => {
      cc.fillStyle = "rgba(230,236,245,0.9)"; cc.font = font(600, 16); cc.textAlign = "left"; cc.fillText("新着メッセージ", -46, -60);
      cc.fillStyle = "rgba(120,170,230,0.6)"; rr(cc, -46, -44, 92, 26, 8); cc.fill();
    } });
    mug(c, t, 300 + wIn * 2000, 950, 1.5, 0.8);
  });
  c.restore();
}

// ================= D: 並べてみると — 二つの壁 =================
function sceneSplit(c: Ctx, t: number) {
  const l = t - P10.at;
  const slide = ease.out(prog(l, 24.2, 25.1));
  const k = ease.inOut(prog(l, 24.2, 34.8));
  const left = win(l, 26.5, 30.4, 0.5), right = win(l, 30.5, 34.9, 0.5);
  c.save();
  cam(c, t, lerp(1.18, 1.0, k), lerp(0, 0, k) + 60 * (right - left), 0, 0.4);
  c.fillStyle = "#07090C"; c.fillRect(-400, -400, W + 800, H + 800);
  // sol: 土壁 + ことわざ
  dof(c, 6 * right, () => {
    c.save(); c.translate(-(1 - slide) * 1100, 0);
    earthWall(c, -300, 950, -200, 860, 0.7 + 0.5 * left, 31);
    beam(c, 0, -200, 900, 40); beam(c, 930, -200, 900, 40);
    SCR.forEach((s, i) => hangingScroll(c, t, 170 + i * 300, 230, 160, 470, { text: s.text, seed: 5 + i, glow: left, dim: 0.35 * right }));
    candle(c, t, 470, 850, 0.9, 3);
    c.fillStyle = "#1E1610"; c.fillRect(-300, 850, 1250, 300);
    c.restore();
  });
  // sağ: ekran duvarı + gündelik sözler
  dof(c, 6 * left, () => {
    c.save(); c.translate((1 - slide) * 1100, 0);
    const wg = c.createLinearGradient(970, 0, 2200, 0);
    wg.addColorStop(0, "#0E1622"); wg.addColorStop(1, "#0A0F17");
    c.fillStyle = wg; c.fillRect(970, -200, 1400, 1060);
    for (let i = 0; i < 18; i++) { c.fillStyle = `rgba(90,150,210,${0.05 + 0.04 * rnd(i, 4)})`; rr(c, 1000 + (i % 6) * 160, 100 + Math.floor(i / 6) * 240, 140, 200, 10); c.fill(); }
    FEED.forEach((f, i) => chatBubble(c, 1080 + (i % 2) * 120, 260 + i * 170, f.txt, 1, { side: -1, size: 36, who: f.who, avatar: f.av, hot: right, time: "" }));
    c.fillStyle = "#0A0D12"; c.fillRect(970, 850, 1400, 300);
    for (let i = 0; i < 3; i++) phone(c, t, 1200 + i * 230, 880, 0.55, { rot: 1.5, glow: 0.4 + 0.6 * right, buzz: right * win(l, 30.7 + i * 0.25, 31.0 + i * 0.25, 0.05) });
    c.restore();
  });
  // dikiş ışığı
  c.fillStyle = `rgba(242,230,200,${0.3 * slide})`; c.fillRect(957, -300, 6, H + 600);
  c.restore();
  // etiketler: fırçayla / dijital
  layer(c, ease.out(prog(l, 28.4, 29.2)) * (1 - prog(l, 34.3, 34.8)), () => {
    c.fillStyle = "rgba(232,222,198,0.92)"; rr(c, 150, 92, 560, 92, 6); c.fill();
    c.save(); c.beginPath(); c.rect(150, 92, 560 * prog(l, 28.4, 29.4), 92); c.clip();
    c.fillStyle = "#16120E"; c.font = font(700, 54, true); c.textAlign = "center"; c.fillText("昔からのことわざ", 430, 158); c.restore();
  });
  layer(c, ease.out(prog(l, 32.78, 33.0)) * (1 - prog(l, 34.3, 34.8)), () => {
    c.fillStyle = "rgba(14,24,36,0.92)"; rr(c, 1210, 92, 560, 92, 12); c.fill();
    c.strokeStyle = "rgba(140,200,255,0.6)"; c.lineWidth = 2; rr(c, 1210, 92, 560, 92, 12); c.stroke();
    const txt = "日々の言葉", n = Math.floor(clamp(prog(l, 32.78, 33.5)) * 5 + 0.001);
    c.fillStyle = "#DDEBFA"; c.font = font(700, 54); c.textAlign = "center"; c.fillText(txt.slice(0, n) + (Math.sin(t * 10) > 0 ? "｜" : "　"), 1490, 158);
  });
}

// ================= E: そのあいだで迷う — 二つの壁の間の廊下 =================
function sceneBetween(c: Ctx, t: number) {
  const l = t - P10.at;
  const k = ease.inOut(prog(l, 34.2, 47.4));
  const lookR = win(l, 38.0, 41.3, 0.35), lookL = win(l, 41.36, 44.7, 0.35), mid = ease.out(prog(l, 44.7, 45.3));
  const face = lookR - lookL;
  const VX = 960, VY = 470;
  c.save();
  cam(c, t, lerp(1.0, 1.14, k), -face * 70, lerp(0, -20, k), 0.6, 960, 600);
  c.fillStyle = "#08090C"; c.fillRect(-400, -400, W + 800, H + 800);
  // koridor sonu: karanlık kapı ışığı
  c.fillStyle = "#12161C"; c.fillRect(VX - 160, VY - 230, 320, 360);
  // sol duvar (土壁, sıcak) — perspektif
  c.save(); c.beginPath(); c.moveTo(-400, -300); c.lineTo(VX - 160, VY - 230); c.lineTo(VX - 160, VY + 130); c.lineTo(-400, H + 300); c.closePath(); c.clip();
  earthWall(c, -400, VX, -300, H + 300, 0.55 + 0.6 * lookL, 41);
  for (let i = 0; i < 4; i++) {
    const d = i / 4, x = lerp(80, VX - 200, Math.pow(d, 0.7)), s = lerp(1, 0.25, Math.pow(d, 0.7));
    hangingScroll(c, t, x, lerp(120, VY - 200, Math.pow(d, 0.7)), 150 * s, 440 * s, { text: SCR[i % 3].text, seed: 9 + i, glow: lookL, dim: 0.5 * (1 - lookL) + 0.2 * lookR });
  }
  c.restore();
  // sağ duvar (ekranlar, soğuk)
  c.save(); c.beginPath(); c.moveTo(W + 400, -300); c.lineTo(VX + 160, VY - 230); c.lineTo(VX + 160, VY + 130); c.lineTo(W + 400, H + 300); c.closePath(); c.clip();
  c.fillStyle = "#0B121C"; c.fillRect(VX, -300, W, H + 600);
  for (let i = 0; i < 5; i++) for (let r = 0; r < 3; r++) {
    const d = i / 5, x = lerp(1800, VX + 200, Math.pow(d, 0.7)), s = lerp(1, 0.25, Math.pow(d, 0.7));
    const fl = 0.35 + 0.65 * lookR * (0.8 + 0.2 * Math.sin(t * 7 + i + r));
    c.fillStyle = `rgba(80,150,220,${0.25 * fl + 0.06})`; rr(c, x - 70 * s, lerp(160, VY - 160, Math.pow(d, 0.7)) + r * 170 * s, 140 * s, 130 * s, 8 * s); c.fill();
    c.fillStyle = `rgba(220,236,250,${0.35 * fl})`; c.fillRect(x - 50 * s, lerp(200, VY - 130, Math.pow(d, 0.7)) + r * 170 * s, 100 * s, 10 * s);
  }
  c.restore();
  // zemin
  c.save(); c.beginPath(); c.moveTo(-400, H + 300); c.lineTo(VX - 160, VY + 130); c.lineTo(VX + 160, VY + 130); c.lineTo(W + 400, H + 300); c.closePath(); c.clip();
  const fg = c.createLinearGradient(0, VY + 130, 0, H + 200); fg.addColorStop(0, "#15120F"); fg.addColorStop(1, "#2A2119");
  c.fillStyle = fg; c.fillRect(-400, VY, W + 800, H);
  c.strokeStyle = "rgba(0,0,0,0.35)"; c.lineWidth = 2;
  for (let i = -8; i <= 8; i++) { c.beginPath(); c.moveTo(VX + i * 20, VY + 130); c.lineTo(VX + i * 260, H + 300); c.stroke(); }
  c.restore();
  // ışık havuzları: sol sıcak, sağ soğuk
  lightPool(c, 300, 760, 600, "rgba(255,190,120,", 0.12 + 0.25 * lookL);
  lightPool(c, 1620, 760, 600, "rgba(120,190,255,", 0.10 + 0.25 * lookR);
  // kararsız figür
  const sway = Math.sin(t * 0.9) * 6;
  drawPerson(c, 960 + sway, 900, 1.25, { outfit: 1, pose: "stand", facing: face * 0.9, rim: 0.9, rimSide: face >= 0 ? 1 : -1, eye: 1, gazeX: face, bob: breathe(t), shade: 0.15 });
  c.restore();
  // söz balonları
  layer(c, lookR, () => chatBubble(c, 1260, 300, "アピールしないと評価されない", ease.out(prog(l, 38.0, 38.5)), { side: -1, size: 38, avatar: "#6A4E8A", hot: 0.6 }));
  layer(c, lookL, () => {
    const p = prog(l, 42.0, 43.6);
    c.fillStyle = "rgba(232,222,198,0.92)"; rr(c, 180, 240, 520, 96, 6); c.fill();
    c.save(); c.beginPath(); c.rect(180, 240, 520 * p, 96); c.clip();
    c.fillStyle = "#16120E"; c.font = font(700, 52, true); c.textAlign = "center"; c.fillText("見てる人は見てる", 440, 306); c.restore();
  });
  // 結局、どっち？ — mürekkep soru işareti
  layer(c, mid * (1 - prog(l, 47.0, 47.5)), () => {
    const s = lerp(1.4, 1, ease.out(prog(l, 45.44, 46.0)));
    c.save(); c.translate(960, 340); c.scale(s, s);
    c.font = font(700, 220, true); c.textAlign = "center";
    c.fillStyle = "rgba(232,234,238,0.85)"; c.shadowColor = "rgba(0,0,0,0.6)"; c.shadowBlur = 20;
    c.fillText("？", 0, 70); c.restore();
  });
}

// ================= F: 見せている側 — 舞台の A =================
function sceneStage(c: Ctx, t: number) {
  const l = t - P10.at;
  const wIn = 1 - ease.out(prog(l, 46.9, 47.5));
  const k = ease.inOut(prog(l, 47.0, 51.6));
  const sp = ease.out(prog(l, 47.85, 48.1));
  const push = ease.inOut(prog(l, 49.3, 51.4));
  c.save();
  dof(c, wIn * 18, () => {
    c.save();
    cam(c, t, lerp(1.0, 1.0, k) + 0.35 * push, -wIn * 1800 + lerp(0, -60, push), lerp(0, 90, push), 0.5, 1060, 520);
    c.fillStyle = "#0A0C10"; c.fillRect(-400, -400, W + 800, H + 800);
    // perde (kadife bordo)
    for (const sd of [-1, 1]) for (let i = 0; i < 6; i++) {
      const x = 960 + sd * (760 + i * 50);
      const g = c.createLinearGradient(x - 25, 0, x + 25, 0);
      g.addColorStop(0, "#3A0E14"); g.addColorStop(0.5, "#6A1A22"); g.addColorStop(1, "#2A0A0E");
      c.fillStyle = g; c.fillRect(x - 26 + Math.sin(t * 0.7 + i) * 3, -100, 52, 980);
    }
    c.fillStyle = "#4A1218"; c.fillRect(-200, -100, W + 400, 110);
    // perde arkası ekran: yükselen grafik
    c.fillStyle = "#121A26"; c.fillRect(560, 120, 800, 420);
    for (let i = 0; i < 6; i++) { const h = (60 + i * 50) * ease.out(prog(l, 47.4 + i * 0.12, 48.4 + i * 0.12)); c.fillStyle = i === 5 ? C.yellow : "rgba(120,170,230,0.75)"; c.fillRect(620 + i * 118, 500 - h, 70, h); }
    c.strokeStyle = "rgba(242,207,58,0.9)"; c.lineWidth = 4; c.beginPath();
    for (let i = 0; i < 6; i++) { const x = 655 + i * 118, y = 470 - (60 + i * 50) * ease.out(prog(l, 47.4 + i * 0.12, 48.4 + i * 0.12)); i ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke();
    c.fillStyle = "#DDE6F2"; c.font = font(700, 34); c.textAlign = "left"; c.fillText("今期の成果", 600, 170);
    // sahne zemini
    c.fillStyle = "#2A2018"; c.fillRect(-200, 790, W + 400, 400);
    c.fillStyle = "#3A2C20"; c.fillRect(-200, 790, W + 400, 12);
    spotlight(c, t, 1180, -40, 820, 260, sp);
    // A: kürsüde konuşur (jest)
    const gest = 0.3 + 0.4 * Math.max(0, Math.sin(t * 2.6));
    drawPerson(c, 1180, 820, 1.2, { outfit: 0, pose: "stand", armUp: gest * sp, rim: 0.4 + 0.6 * sp, rimSide: -1, facing: -0.25, eye: 1, gazeX: -0.4, bob: breathe(t), glow: 0.25 * sp });
    c.fillStyle = "#3A2A1C"; c.beginPath(); c.moveTo(1060, 640); c.lineTo(1300, 640); c.lineTo(1280, 820); c.lineTo(1080, 820); c.closePath(); c.fill(); // kürsü
    c.fillStyle = "#16181C"; c.fillRect(1180, 600, 5, 44); c.beginPath(); c.arc(1182, 598, 9, 0, Math.PI * 2); c.fill();
    dust(c, t, 30, 0.3 * sp, 61);
    c.restore();
  });
  // ön plan: seyirci başları (DOF)
  dof(c, 6, () => {
    [[260, 3], [720, 5], [1500, 2], [1880, 4]].forEach(([x, o], i) => drawPerson(c, x - wIn * 2400 - push * 80, 1360, 1.8, { outfit: o, pose: "sit", shade: 0.7, rim: 0.5 * sp, rimSide: 1, facing: x < 1100 ? 0.3 : -0.3, bob: breathe(t, i) }));
  });
  c.restore();
  layer(c, ease.out(prog(l, 49.6, 50.1)) * (1 - prog(l, 51.0, 51.4)), () => { c.font = font(700, 120, true); c.fillStyle = "rgba(232,234,238,0.8)"; c.textAlign = "center"; c.fillText("？", 1440, 330); });
}

// ================= G: 100人の調査 — 58.6% / 32.3% =================
const ORDER = Array.from({ length: 100 }, (_, i) => i).sort((a, b) => rnd(a, 71) - rnd(b, 71));
const RANK = new Array(100); ORDER.forEach((v, i) => (RANK[v] = i));
function sceneSurvey(c: Ctx, t: number) {
  const l = t - P11.at;
  const k = ease.inOut(prog(l, -0.4, 12.6));
  c.save();
  cam(c, t, lerp(1.12, 1.0, k), lerp(80, -40, k), 0, 0.35);
  c.fillStyle = C.bg; c.fillRect(-400, -400, W + 800, H + 800);
  boardGrid(c, 0.9);
  // kağıt pano
  c.fillStyle = "rgba(24,30,40,0.9)"; rr(c, 230, 160, 860, 620, 14); c.fill();
  c.strokeStyle = "rgba(140,151,168,0.3)"; c.lineWidth = 2; rr(c, 230, 160, 860, 620, 14); c.stroke();
  for (let i = 0; i < 100; i++) {
    const r = RANK[i];
    const lit = r < 59 ? ease.out(prog(l, 3.3 + r * 0.026, 3.6 + r * 0.026)) : 0;
    const tired = r < 59 && r % 2 === 0 && r < 64 ? 0 : 0;
    const tr = (r < 59 && (r * 7) % 59 < 32) ? ease.inOut(prog(l, 9.9 + ((r * 7) % 59) * 0.03, 10.6 + ((r * 7) % 59) * 0.03)) : 0;
    figureIcon(c, 300 + (i % 10) * 80 + Math.sin(t * 1.3 + i) * 1.2, 250 + Math.floor(i / 10) * 56, 1.05, lit, tr + tired);
  }
  // sayaçlar
  const v1 = 58.6 * ease.out(prog(l, 3.3, 5.0)), v2 = 32.3 * ease.out(prog(l, 9.9, 11.1));
  layer(c, ease.out(prog(l, 1.4, 2.0)), () => {
    c.textAlign = "left"; c.font = font(500, 34); c.fillStyle = C.text; c.fillText("評価のために、意識して", 1180, 290); c.fillText("自分をアピールしている", 1180, 340);
    c.font = font(700, 120); c.fillStyle = C.yellow; c.fillText(v1.toFixed(1) + "%", 1180, 470);
  });
  layer(c, ease.out(prog(l, 7.0, 7.6)), () => {
    c.textAlign = "left"; c.font = font(500, 34); c.fillStyle = C.text; c.fillText("アピールすることに", 1180, 590); c.fillText("疲れを感じている", 1180, 640);
    c.font = font(700, 120); c.fillStyle = "#9AA6BA"; c.fillText(v2.toFixed(1) + "%", 1180, 770);
  });
  c.restore();
  boardLabel(c, 160, 100, "調査", 1, C.yellow);
}

// ================= H: 舞台裏 — 見えている側の不安 =================
function sceneBackstage(c: Ctx, t: number) {
  const l = t - P11.at;
  const k = ease.inOut(prog(l, 12.0, 21.2));
  const walk = prog(l, 12.2, 14.4);
  const sat = ease.inOut(prog(l, 14.2, 14.7));
  const anx = win(l, 15.2, 20.8, 0.5);
  c.save();
  cam(c, t, lerp(1.0, 1.15, k), lerp(200, -120, k), lerp(0, 30, k), 0.7, 1100, 600);
  c.fillStyle = "#0B0D11"; c.fillRect(-400, -400, W + 800, H + 800);
  // sol: sahne (kenardan parlak)
  dof(c, 5, () => {
    spotlight(c, t, 200, -40, 820, 300, 1);
    c.fillStyle = "#2A2018"; c.fillRect(-400, 800, 820, 400);
    for (let i = 0; i < 4; i++) { const x = 480 + i * 46; const g = c.createLinearGradient(x - 24, 0, x + 24, 0); g.addColorStop(0, "#3A0E14"); g.addColorStop(0.5, "#6A1A22"); g.addColorStop(1, "#2A0A0E"); c.fillStyle = g; c.fillRect(x - 24, -100, 48, 1000); }
  });
  // kulis duvarı: tuğla + kablolar + ayna
  c.fillStyle = "#1A1714"; c.fillRect(620, -200, 1900, 1000);
  for (let r = 0; r < 18; r++) for (let q = 0; q < 26; q++) { c.fillStyle = rnd(r * 30 + q, 5) > 0.5 ? "#231E1A" : "#1E1A16"; c.fillRect(640 + q * 72 + (r % 2) * 36, -180 + r * 50, 66, 44); }
  c.strokeStyle = "#0E0F11"; c.lineWidth = 5; c.beginPath(); c.moveTo(640, 120); c.bezierCurveTo(900, 220, 1200, 90, 1600, 200); c.stroke();
  // ayna + ampuller
  c.fillStyle = "#2A2E36"; c.fillRect(1500, 220, 340, 300);
  c.fillStyle = "#151A22"; c.fillRect(1520, 240, 300, 260);
  for (let i = 0; i < 6; i++) { const on = i === 3 ? (Math.sin(t * 23) > 0.3 ? 0.2 : 1) : 1; c.fillStyle = `rgba(255,226,170,${0.85 * on})`; c.beginPath(); c.arc(1520 + i * 60, 214, 9, 0, Math.PI * 2); c.fill(); }
  // 「余裕」 slayt çıktısı — 限りません'de düşer
  const fall = ease.in(prog(l, 19.3, 20.2));
  c.save(); c.translate(1000 + fall * 60, 300 + fall * 520); c.rotate(-0.04 + fall * 1.2 + Math.sin(t * 2) * 0.01 * (1 - fall));
  c.fillStyle = "#E4DED0"; c.fillRect(-150, -100, 300, 200);
  c.fillStyle = "#1A1D24"; c.font = font(800, 76); c.textAlign = "center"; c.fillText("余裕", 0, 10);
  c.font = font(500, 24); c.fillStyle = "#5B6678"; c.fillText("今期も順調です！", 0, 62);
  c.restore();
  layer(c, 1 - fall, () => { c.fillStyle = "#B83A30"; c.beginPath(); c.arc(1000, 214, 8, 0, Math.PI * 2); c.fill(); });
  // çalışma lambası (titrer, 不安)
  spotlight(c, t, 1240, 40, 820, 200, 0.6, anx * 0.8, "255,214,160");
  // zemin + sandık
  c.fillStyle = "#16130F"; c.fillRect(620, 800, 1900, 400);
  c.fillStyle = "#3A2C1E"; c.fillRect(1120, 690, 240, 120); c.strokeStyle = "#1C140C"; c.lineWidth = 4; c.strokeRect(1120, 690, 240, 120);
  c.beginPath(); c.moveTo(1120, 690); c.lineTo(1360, 810); c.moveTo(1360, 690); c.lineTo(1120, 810); c.stroke();
  // A: sahneden yürüyerek çıkar → sandığa oturur, telefona bakar
  const ax = lerp(420, 1240, ease.inOut(walk));
  if (sat < 0.5) drawPerson(c, ax, 815, 1.1, { outfit: 0, pose: "stand", walk: walk < 1 ? (l - 12.2) * 1.6 : -1, rim: 0.8, rimSide: -1, facing: 0.6, tie: true, bob: breathe(t) });
  else drawPerson(c, 1240, 700, 1.1, { outfit: 0, pose: "sit", rim: 0.6, rimSide: -1, facing: -0.2, tie: true, eye: 1, gazeX: -0.2, bob: breathe(t) * 0.5 + 6 * anx });
  layer(c, sat, () => phone(c, t, 1190, 610, 0.42, { rot: -0.3, glow: 0.8, content: (cc) => { typingDots(cc, t, -48, -20, win(l, 15.0, 16.6, 0.2) + win(l, 17.6, 18.6, 0.2)); cc.fillStyle = "rgba(200,210,225,0.7)"; cc.font = font(500, 16); cc.textAlign = "center"; cc.fillText("既読 0", 0, 80); } }));
  // kalp atışı halkası (不安)
  for (let i = 0; i < 2; i++) { const ph = ((l - 15.2) * 1.1 + i * 0.5) % 1; if (anx > 0 && ph >= 0) { c.strokeStyle = `rgba(226,96,58,${0.3 * anx * (1 - ph)})`; c.lineWidth = 3; c.beginPath(); c.arc(1240, 540, 60 + ph * 160, 0, Math.PI * 2); c.stroke(); } }
  c.restore();
  layer(c, win(l, 15.3, 20.6, 0.4), () => boardLabel(c, 160, 100, "見てもらえるかどうかの不安", 1, C.mist));
}

// ================= I: 静かな側 — 見てる人は、見てる =================
function sceneQuiet(c: Ctx, t: number) {
  const l = t - P11.at;
  const k = ease.inOut(prog(l, 20.6, 29.6));
  const rack = ease.inOut(prog(l, 21.6, 22.8));
  const see = ease.out(prog(l, 25.7, 27.6));
  c.save();
  cam(c, t, lerp(1.18, 1.04, k), lerp(-40, 20, k), lerp(20, -10, k), 0.45, 960, 580);
  dof(c, lerp(6, 3, rack), () => envOffice(c, t, 4, -l * 4));
  dof(c, lerp(5, 0, rack), () => {
    wallClock(c, 1540, 230, 52, 22.2 + l / 3600);
    // pano + küçük washi notu
    c.fillStyle = "#5A4630"; c.fillRect(380, 260, 300, 220); c.fillStyle = "#7A6248"; c.fillRect(390, 270, 280, 200);
    const nt = ease.out(prog(l, 23.0, 23.8));
    c.save(); c.translate(530, 370); c.rotate(-0.05); c.globalAlpha *= 0.4 + 0.6 * nt;
    c.fillStyle = "#E6DCC2"; c.fillRect(-46, -80, 92, 160);
    c.fillStyle = "#16120E"; c.font = font(700, 22, true); c.textAlign = "center";
    [..."見てる人は"].forEach((ch, i) => c.fillText(ch, 0, -50 + i * 27));
    c.restore();
    c.fillStyle = "#B83A30"; c.beginPath(); c.arc(530, 296, 6, 0, Math.PI * 2); c.fill();
    officeDesk(c, 960, 760, 1.25, 0.6, 1);
    drawPerson(c, 900, 800, 1.2, { outfit: 2, pose: "desk", rim: 0.6 + 0.4 * see, rimSide: 1, facing: 0.3, eye: 1, gazeX: 0.3, bob: breathe(t) * 0.6, glow: 0.35 * see });
    // B: kabloları toplar / belgeyi düzeltir (ikincil hareket)
    plant(c, t, 1280, 744, 1.1);
  });
  // ön plan kupa (rack focus: önce net, sonra bulanık)
  dof(c, lerp(0, 8, rack), () => mug(c, t, 300, 1020, 2.4, 1));
  c.restore();
  // son söz: yumuşak sarı
  const a1 = ease.out(prog(l, 25.6, 26.6)), a2 = ease.out(prog(l, 27.0, 27.8));
  layer(c, (a1) * (1 - prog(l, 28.6, 29.6)), () => {
    c.save(); c.textAlign = "center"; c.font = font(700, 86, true);
    c.shadowColor = "rgba(242,207,58,0.45)"; c.shadowBlur = 30;
    c.fillStyle = `rgba(242,214,110,${0.92})`;
    c.fillText("見てる人は、", 820, 250);
    c.globalAlpha *= a2; c.fillText("見てる。", 1250, 250);
    c.restore();
  });
  dust(c, t, 36, 0.25, 71);
}

// ================= ÇİZİM =================
const SCENES: [number, number, (c: Ctx, t: number) => void, Lens][] = [
  [g10(-0.8), g10(5.0), sceneStudy, LENS_WASHI],
  [g10(4.4), g10(12.4), sceneScrolls, LENS_WASHI],
  [g10(11.9), g10(24.9), sceneFeed, LENS_SCREEN],
  [g10(24.2), g10(34.9), sceneSplit, LENS.doc],
  [g10(34.3), g10(47.5), sceneBetween, LENS.night],
  [g10(46.9), CARD_A + 0.6, sceneStage, LENS_STAGE],
  [CARD_B - 0.4, g11(12.7), sceneSurvey, LENS.doc],
  [g11(12.1), g11(21.2), sceneBackstage, LENS_STAGE],
  [g11(20.6), END, sceneQuiet, LENS.night],
];
const HARD = new Set<any>([sceneFeed, sceneStage]); // whip-pan girişli

function draw(ctx: Ctx, t: number) {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H);
  const active = SCENES.filter(([a, b]) => t >= a && t <= b);
  const L = active.length ? active[active.length - 1][3] : LENS.night;
  if (active.length) {
    lens(ctx, t, L, (c) => {
      for (const [a, , fn] of active) layer(c, HARD.has(fn) || a <= g10(-0.8) ? 1 : ease.sine(prog(t, a, a + 0.6)), () => fn(c, t));
    });
  }
  whipStreaks(ctx, Math.sin(Math.PI * prog(t, g10(11.8), g10(12.6))), 1, 3);
  whipStreaks(ctx, Math.sin(Math.PI * prog(t, g10(46.8), g10(47.6))), -1, 7);
  sectionTitle(ctx, t, 0.0, 3.6, "05", "見てる人は見てる？");
  statPair(ctx, t, CARD_A, CARD_B + 0.2, { items: [{ value: 58.6, caption: "意識して自分をアピールしている" }, { value: 32.3, caption: "アピールに疲れを感じている", hot: false }], source: SRC });
  sourceCard(ctx, t, g11(0.3), g11(11.8), SRC);
  drawSubtitles(ctx, parts, t);
  fadeBlack(ctx, 1 - prog(t, 0, 0.5));
  fadeBlack(ctx, prog(t, END - 1.8, END - 0.2));
}

// ================= SES EFEKTLERİ (eyleme bire bir) =================
const cues: Cue[] = [];
const cue = (t: number, type: string, gain = 1, p: Record<string, number> = {}) => cues.push({ t, type, gain, p });

cue(0.0, "room", 0.5, { d: END });
cue(0.35, "whoosh", 0.55, { d: 1.2 });
cue(g10(0.1), "match", 0.5);                                        // andon yakılır
cue(g10(1.2), "woodtap", 0.3);                                      // fırça fırçalıktan kalkar
cue(g10(1.6), "drip", 0.5);                                         // mürekkebe batar
cue(g10(2.45), "brush", 0.55, { d: 1.3 });                          // 言葉 yazılır
[0, 1, 2].forEach((i) => cue(g10(3.7 + i * 0.22), "scrollunroll", 0.22, { d: 0.6 })); // shoji'ye rulo gölgeleri
cue(g10(4.4), "whoosh", 0.3, { d: 1.0 });
SCR.forEach((s) => {
  cue(g10(s.un), "scrollunroll", 0.5, { d: 0.7 });                  // kakejiku açılır
  cue(g10(s.rv[0]), "brush", 0.45, { d: s.rv[1] - s.rv[0] });      // fırça yazısı
});
cue(g10(6.0), "creak", 0.45, { d: 1.0 });                           // 縁の下: döşeme gıcırtısı
cue(g10(8.55), "stamp", 0.6);                                       // 不言実行: hanko
cue(g10(9.75), "wingflap", 0.5);                                    // 鷹 kanat
cue(g10(10.6), "rustle", 0.3);                                      // 爪を隠す: tüyler örter
cue(g10(11.8), "whoosh", 0.8, { d: 0.8 });                          // whip-pan → ofis
cue(g10(12.5), "hvac", 0.25, { d: 12.0 });                          // ofis klima uğultusu
for (let i = 0; i < 8; i++) cue(g10(13.0 + i * 0.13), "type", 0.14);  // klavye
FEED.forEach((f, i) => { cue(g10(f.at - 0.15), "notify", 0.5, { f: [880, 988, 1046][i] }); cue(g10(f.at), "buzz", 0.4); });
cue(g10(19.3), "murmur", 0.35, { d: 3.4 });                         // 声が大きい: arka plan konuşması
cue(g10(22.55), "trophy", 0.5);                                     // kupa
cue(g10(24.2), "slide", 0.6, { d: 0.9 });                           // iki duvar kayar
cue(g10(25.05), "thunk", 0.55);                                     // birleşir
cue(g10(26.6), "swish", 0.3);                                       // rack focus → sol
cue(g10(28.4), "brush", 0.4, { d: 1.0 });                           // 昔からのことわざ
cue(g10(30.6), "swish", 0.3);                                       // rack focus → sağ
[0, 1, 2].forEach((i) => cue(g10(30.7 + i * 0.25), "buzz", 0.3));   // telefonlar titrer
for (let i = 0; i < 5; i++) cue(g10(32.78 + i * 0.14), "type", 0.25); // 日々の言葉
cue(g10(34.3), "whoosh", 0.35, { d: 1.2 });
cue(g10(35.6), "heartbeat", 0.35, { d: 2.4 });                      // 迷っています
cue(g10(38.0), "step", 0.35); cue(g10(38.1), "notify", 0.35, { f: 880 }); // sağa döner
cue(g10(41.4), "step", 0.35); cue(g10(42.0), "brush", 0.4, { d: 1.4 });   // sola döner, fırça yazısı
cue(g10(45.44), "lowdrone", 0.35, { d: 1.6 });                      // ？
cue(g10(46.8), "whoosh", 0.8, { d: 0.8 });                          // whip-pan → sahne
cue(g10(47.85), "spoton", 0.75);                                    // spot ışığı yanar
cue(g10(48.0), "murmur", 0.25, { d: 2.6 });                         // seyirci
cue(g10(49.4), "swish", 0.3);                                       // push-in
cue(CARD_A, "whoosh", 0.4, { d: 1.2 });
for (let i = 0; i < 10; i++) cue(CARD_A + 0.25 + i * 0.14, "tally", 0.18, { f: 1300 + i * 30 }); // 58.6 sayacı
for (let i = 0; i < 8; i++) cue(CARD_A + 0.95 + i * 0.16, "tally", 0.14, { f: 700 });           // 32.3 (donuk)
cue(CARD_B, "whoosh", 0.35, { d: 1.0 });
cue(g11(0.3), "paper", 0.4);                                        // pano kağıdı
for (let i = 0; i < 20; i++) cue(g11(3.3 + i * 0.077), "rustle", 0.06);                          // eller kalkar
for (let i = 0; i < 12; i++) cue(g11(3.3 + i * 0.14), "tally", 0.2, { f: 1400 + i * 20 });     // 58.6% sayacı
[0, 1, 2].forEach((i) => cue(g11(9.95 + i * 0.3), "sigh", 0.4 - i * 0.08));                     // yorgunluk: iç çekiş
cue(g11(12.1), "whoosh", 0.35, { d: 1.0 });
for (let s = 12.3; s < 14.3; s += 0.45) cue(g11(s), "step", 0.35);  // sahneden yürüyüp çıkar
cue(g11(14.5), "woodtap", 0.5);                                     // sandığa oturur
cue(g11(14.9), "buzz", 0.25);                                       // telefon
cue(g11(15.2), "heartbeat", 0.45, { d: 5.0 });                      // 不安
cue(g11(15.3), "flicker", 0.5, { d: 4.6 });                         // lamba titrer
cue(g11(19.3), "click", 0.35);                                      // raptiye çıkar
cue(g11(19.4), "paper", 0.45);                                      // 余裕 kağıdı düşer
cue(g11(20.25), "flick", 0.35);
cue(g11(20.6), "whoosh", 0.3, { d: 1.2 });
for (let s = 21.0; s < 29.0; s += 1.0) cue(g11(s), "tick", 0.12);   // duvar saati
cue(g11(21.6), "swish", 0.25);                                      // rack focus
cue(g11(23.0), "paper", 0.3);                                       // washi notu
cue(g11(25.7), "shimmer", 0.3, { f: 523 });                         // 見てる人は、 (geçiş benzeri yumuşak tını)
cue(g11(27.0), "chime", 0.35, { f: 784 });                          // 見てる。
cue(END - 1.9, "whoosh", 0.3, { d: 1.5 });

export const s05: Section = { id: "s05", duration: END, parts, cues, draw };
void bokeh; void rr;
