// s05'te doğan ortak parçalar: "ことわざ vs 日々の言葉" motifleri.
// hangingScroll (掛け軸 + fırça yazısı), chatBubble / phone (gündelik söz), spotlight (sahne ışığı),
// sumiHawk / sumiFloor (sumi-e illüstrasyonlar), figureIcon (pano figürü). s08/s11'de tekrar kullanılabilir.
import { clamp, ease, lerp, rnd } from "../engine/core";
import { C, font, rr } from "../design/style";
type Ctx = CanvasRenderingContext2D;

/** 掛け軸: dikey fırça yazısı. reveal 0..1 karakter karakter, unroll 0..1 yukarıdan açılır. */
export function hangingScroll(c: Ctx, t: number, x: number, y: number, w: number, h: number,
  o: { text: string; reveal?: number; unroll?: number; sway?: number; glow?: number; dim?: number; seed?: number; size?: number; art?: (c: Ctx, w: number, h: number) => void }) {
  const un = ease.out(clamp(o.unroll ?? 1)), rev = o.reveal ?? 1, seed = o.seed ?? 0;
  const sw = Math.sin(t * 0.9 + seed) * (o.sway ?? 0.008);
  c.save(); c.translate(x, y); c.rotate(sw);
  // askı ipi
  c.strokeStyle = "#2A2118"; c.lineWidth = 2.5; c.beginPath(); c.moveTo(-w * 0.3, 0); c.lineTo(0, -46); c.lineTo(w * 0.3, 0); c.stroke();
  c.fillStyle = "#0E0C0A"; c.beginPath(); c.arc(0, -48, 5, 0, Math.PI * 2); c.fill();
  const hh = Math.max(14, h * un);
  // gölge
  c.fillStyle = "rgba(0,0,0,0.38)"; c.fillRect(-w / 2 + 14, 16, w, hh);
  // brokar kenar (yerel renk: koyu çivit + altın iplik)
  c.fillStyle = "#2B3350"; c.fillRect(-w / 2, 0, w, hh);
  c.fillStyle = "rgba(196,160,92,0.25)";
  for (let i = 0; i < hh / 18; i++) c.fillRect(-w / 2 + 6 + (i % 2) * 8, i * 18 + 4, 4, 4), c.fillRect(w / 2 - 14 - (i % 2) * 8, i * 18 + 10, 4, 4);
  // washi
  const px = -w / 2 + w * 0.12, pw = w * 0.76, py = h * 0.1, ph = Math.max(0, hh - h * 0.2);
  if (ph > 0) {
    const pg = c.createLinearGradient(0, py, 0, py + ph);
    pg.addColorStop(0, "#EAE0C8"); pg.addColorStop(1, "#D6C9A8");
    c.fillStyle = pg; c.fillRect(px, py, pw, ph);
    // lif dokusu
    c.fillStyle = "rgba(120,100,70,0.12)";
    for (let i = 0; i < 70; i++) { const fy = rnd(i, seed + 3) * h * 0.8; if (fy < ph) c.fillRect(px + rnd(i, seed + 4) * pw, py + fy, 1 + rnd(i, seed + 5) * 9, 1); }
    // lekelenme (yaşlı kağıt)
    const st = c.createRadialGradient(px + pw * 0.7, py + ph * 0.8, 4, px + pw * 0.7, py + ph * 0.8, pw);
    st.addColorStop(0, "rgba(150,110,60,0.16)"); st.addColorStop(1, "rgba(150,110,60,0)");
    c.fillStyle = st; c.fillRect(px, py, pw, ph);
    if (o.glow) { c.fillStyle = `rgba(255,214,150,${0.18 * o.glow})`; c.fillRect(px, py, pw, ph); }
    // dikey yazı (fırça: koyu mürekkep + taşma)
    c.save(); c.beginPath(); c.rect(px, py, pw, ph); c.clip();
    const chars = [...o.text], size = o.size ?? Math.min(pw * 0.62, (h * 0.78) / (chars.length * 1.08 + 0.4));
    c.font = font(700, size, true); c.textAlign = "center";
    chars.forEach((ch, i) => {
      const k = clamp(rev * chars.length - i);
      if (k <= 0) return;
      const cy = py + size * 1.05 + i * size * 1.08;
      c.save(); c.globalAlpha *= ease.out(k);
      c.shadowColor = "rgba(20,16,12,0.6)"; c.shadowBlur = lerp(14, 2, k);
      c.fillStyle = "#16120E";
      c.translate(0, cy); c.scale(lerp(1.15, 1, k), lerp(1.15, 1, k));
      c.fillText(ch, 0, 0);
      c.restore();
    });
    if (o.art) { c.save(); c.translate(0, py + ph); o.art(c, pw, ph); c.restore(); }
    c.restore();
  }
  // alt çubuk (jiku)
  c.fillStyle = "#3A2A1C"; c.fillRect(-w / 2 - 12, hh - 6, w + 24, 14);
  c.fillStyle = "#C8A060"; c.beginPath(); c.arc(-w / 2 - 14, hh + 1, 9, 0, Math.PI * 2); c.arc(w / 2 + 14, hh + 1, 9, 0, Math.PI * 2); c.fill();
  // üst çubuk
  c.fillStyle = "#2A1D13"; c.fillRect(-w / 2 - 4, -6, w + 8, 12);
  if (o.dim) { c.fillStyle = `rgba(8,10,14,${o.dim})`; c.fillRect(-w / 2 - 20, -10, w + 40, hh + 24); }
  c.restore();
}

/** Sumi-e şahin: tünekte, pençeler gizli (hide 0..1 tüyler pençeyi örter) */
export function sumiHawk(c: Ctx, x: number, y: number, s: number, k: number, hide = 1, wing = 0) {
  if (k <= 0) return;
  c.save(); c.translate(x, y); c.scale(s, s); c.globalAlpha *= clamp(k);
  c.fillStyle = "rgba(22,18,14,0.88)";
  // tünek dalı
  c.lineWidth = 7; c.strokeStyle = "rgba(22,18,14,0.75)"; c.lineCap = "round";
  c.beginPath(); c.moveTo(-90, 62); c.quadraticCurveTo(0, 48, 90, 58); c.stroke();
  // gövde
  c.beginPath(); c.moveTo(-6, -70); c.quadraticCurveTo(34, -60, 30, -10); c.quadraticCurveTo(26, 40, 4, 56);
  c.quadraticCurveTo(-24, 40, -30, 0); c.quadraticCurveTo(-34, -50, -6, -70); c.fill();
  // kanat (fırça darbesi)
  c.save(); c.rotate(-wing * 0.5);
  c.beginPath(); c.moveTo(14, -40); c.quadraticCurveTo(60, -10, 40, 64 - wing * 30); c.quadraticCurveTo(18, 20, 14, -40); c.fill();
  c.restore();
  // kuyruk
  c.beginPath(); c.moveTo(-4, 50); c.lineTo(-20, 98); c.lineTo(12, 96); c.closePath(); c.fill();
  // baş + gaga
  c.beginPath(); c.arc(-6, -76, 18, 0, Math.PI * 2); c.fill();
  c.beginPath(); c.moveTo(-22, -80); c.quadraticCurveTo(-36, -76, -30, -64); c.lineTo(-20, -72); c.fill();
  c.fillStyle = "#EAE0C8"; c.beginPath(); c.arc(-12, -80, 3.5, 0, Math.PI * 2); c.fill();
  // pençeler: hide azsa görünür
  c.strokeStyle = `rgba(22,18,14,${0.85 * (1 - hide)})`; c.lineWidth = 3;
  for (const sx of [-10, 10]) { c.beginPath(); c.moveTo(sx, 50); c.lineTo(sx - 6, 62); c.moveTo(sx, 50); c.lineTo(sx + 6, 62); c.stroke(); }
  // tüy örtüsü
  c.fillStyle = `rgba(22,18,14,${0.88 * hide})`; c.beginPath(); c.ellipse(0, 54, 20, 10 * hide + 0.1, 0, 0, Math.PI * 2); c.fill();
  c.restore();
}

/** Sumi-e kesit: döşeme tahtası, altında kollarıyla taşıyan figür (縁の下の力持ち) */
export function sumiFloor(c: Ctx, x: number, y: number, s: number, k: number, push = 0) {
  if (k <= 0) return;
  c.save(); c.translate(x, y); c.scale(s, s); c.globalAlpha *= clamp(k);
  const ink = "rgba(22,18,14,0.85)";
  c.fillStyle = ink; c.fillRect(-110, -64 - push * 3, 220, 12);           // döşeme
  for (let i = -2; i <= 2; i++) c.fillRect(i * 46 - 3, -94 - push * 3, 6, 30); // üstündeki ayaklar (ev)
  c.fillRect(-110, 50, 220, 5);                                            // zemin
  c.fillRect(-100, -52, 8, 102); c.fillRect(92, -52, 8, 102);              // direkler
  // taşıyan figür
  c.lineWidth = 7; c.strokeStyle = ink; c.lineCap = "round";
  c.beginPath(); c.arc(0, -16 + push, 10, 0, Math.PI * 2); c.fillStyle = ink; c.fill();
  c.beginPath(); c.moveTo(0, -4 + push); c.lineTo(0, 26); c.moveTo(0, 26); c.lineTo(-14, 48); c.moveTo(0, 26); c.lineTo(14, 48);
  c.moveTo(0, 0 + push); c.lineTo(-22, -50 + push * 0.5); c.moveTo(0, 0 + push); c.lineTo(22, -50 + push * 0.5); c.stroke();
  c.restore();
}

/** Kırmızı hanko (mühür) */
export function hanko(c: Ctx, x: number, y: number, s: number, k: number, txt = "実") {
  if (k <= 0) return;
  const sc = lerp(1.8, 1, ease.out(clamp(k * 1.5)));
  c.save(); c.translate(x, y); c.scale(s * sc, s * sc); c.globalAlpha *= clamp(k * 2) * 0.9;
  c.fillStyle = "#B8322A"; rr(c, -22, -22, 44, 44, 4); c.fill();
  c.fillStyle = "#EAE0C8"; c.font = font(700, 30, true); c.textAlign = "center"; c.fillText(txt, 0, 11);
  c.restore();
}

/** Sohbet uygulaması balonu (gündelik söz). side: -1 sol (başkası), 1 sağ */
export function chatBubble(c: Ctx, x: number, y: number, txt: string, k: number, o: { side?: number; hot?: number; size?: number; who?: string; avatar?: string; time?: string } = {}) {
  if (k <= 0) return;
  const side = o.side ?? -1, size = o.size ?? 40, hot = o.hot ?? 0;
  const sc = lerp(0.5, 1, ease.back(clamp(k)));
  c.save(); c.translate(x, y); c.scale(sc, sc); c.globalAlpha *= clamp(k * 2);
  c.font = font(700, size);
  const tw = c.measureText(txt).width, bw = tw + 56, bh = size + 40;
  const bx = side < 0 ? 0 : -bw;
  // avatar
  c.fillStyle = o.avatar ?? "#4E6A8A"; c.beginPath(); c.arc(side < 0 ? -44 : 44, bh * 0.5, 26, 0, Math.PI * 2); c.fill();
  c.fillStyle = "rgba(255,255,255,0.25)"; c.beginPath(); c.arc(side < 0 ? -44 : 44, bh * 0.5 - 6, 10, 0, Math.PI * 2); c.fill();
  const g = c.createLinearGradient(0, 0, 0, bh);
  if (side < 0) { g.addColorStop(0, "#2A3442"); g.addColorStop(1, "#212A36"); } else { g.addColorStop(0, "#3C8F5A"); g.addColorStop(1, "#2F7448"); }
  c.fillStyle = g; rr(c, bx, 0, bw, bh, 26); c.fill();
  c.beginPath(); if (side < 0) { c.moveTo(4, bh - 22); c.lineTo(-10, bh - 4); c.lineTo(22, bh - 8); } else { c.moveTo(-4, bh - 22); c.lineTo(10, bh - 4); c.lineTo(-22, bh - 8); } c.fill();
  if (hot > 0) { c.strokeStyle = `rgba(150,220,255,${0.7 * hot})`; c.lineWidth = 3; rr(c, bx, 0, bw, bh, 26); c.stroke(); c.shadowColor = "rgba(120,200,255,0.8)"; c.shadowBlur = 24 * hot; }
  c.fillStyle = "#F2F4F7"; c.textAlign = "left"; c.fillText(txt, bx + 28, bh * 0.5 + size * 0.36);
  c.shadowBlur = 0;
  c.font = font(400, 18); c.fillStyle = "rgba(200,210,225,0.5)";
  if (o.who) c.fillText(o.who, bx + 4, -10);
  if (o.time) { c.textAlign = side < 0 ? "left" : "right"; c.fillText(o.time, side < 0 ? bx + bw + 10 : bx - 10, bh - 6); }
  c.restore();
}

/** Yazıyor… göstergesi */
export function typingDots(c: Ctx, t: number, x: number, y: number, k: number) {
  if (k <= 0) return;
  c.save(); c.globalAlpha *= clamp(k * 2);
  c.fillStyle = "#2A3442"; rr(c, x, y, 110, 54, 27); c.fill();
  for (let i = 0; i < 3; i++) { const b = Math.max(0, Math.sin(t * 8 - i * 0.9)); c.fillStyle = `rgba(220,228,240,${0.4 + 0.5 * b})`; c.beginPath(); c.arc(x + 30 + i * 25, y + 27 - b * 5, 7, 0, Math.PI * 2); c.fill(); }
  c.restore();
}

/** Akıllı telefon (masada yatık ya da elde). buzz: titreşim, content: ekran içi çizim */
export function phone(c: Ctx, t: number, x: number, y: number, s: number, o: { rot?: number; glow?: number; buzz?: number; content?: (c: Ctx) => void } = {}) {
  const bz = (o.buzz ?? 0) * Math.sin(t * 90) * 3;
  c.save(); c.translate(x + bz, y); c.rotate(o.rot ?? 0); c.scale(s, s);
  c.fillStyle = "rgba(0,0,0,0.5)"; rr(c, -58, -108, 128, 228, 22); c.fill();
  c.fillStyle = "#15171B"; rr(c, -64, -118, 128, 236, 22); c.fill();
  c.strokeStyle = "#3A3F48"; c.lineWidth = 2; rr(c, -64, -118, 128, 236, 22); c.stroke();
  const gl = o.glow ?? 1;
  const sg = c.createLinearGradient(0, -106, 0, 106);
  sg.addColorStop(0, `rgba(40,60,90,${gl})`); sg.addColorStop(1, `rgba(20,30,48,${gl})`);
  c.fillStyle = sg; rr(c, -56, -106, 112, 212, 14); c.fill();
  if (o.content) { c.save(); c.beginPath(); rr(c, -56, -106, 112, 212, 14); c.clip(); o.content(c); c.restore(); }
  c.fillStyle = "#0A0B0D"; rr(c, -16, -102, 32, 8, 4); c.fill();
  c.restore();
  if (gl > 0.2) { const g = c.createRadialGradient(x, y, 10, x, y, 260 * s); g.addColorStop(0, `rgba(120,170,230,${0.18 * gl})`); g.addColorStop(1, "rgba(120,170,230,0)"); c.fillStyle = g; c.fillRect(x - 300 * s, y - 300 * s, 600 * s, 600 * s); }
}

/** Sahne spot ışığı: tepeden koni + zeminde havuz. flick: titreşim (0..1) */
export function spotlight(c: Ctx, t: number, x: number, top: number, floor: number, r: number, k: number, flick = 0, col = "255,232,190") {
  if (k <= 0) return;
  const f = 1 - flick * (0.5 + 0.5 * Math.sin(t * 37) * Math.sin(t * 11.3)) * (Math.sin(t * 5.1) > 0.2 ? 1 : 0.2);
  const a = clamp(k) * f;
  c.save(); c.globalCompositeOperation = "lighter";
  const g = c.createLinearGradient(0, top, 0, floor);
  g.addColorStop(0, `rgba(${col},${0.32 * a})`); g.addColorStop(1, `rgba(${col},${0.1 * a})`);
  c.fillStyle = g; c.beginPath(); c.moveTo(x - 40, top); c.lineTo(x + 40, top); c.lineTo(x + r, floor); c.lineTo(x - r, floor); c.closePath(); c.fill();
  const p = c.createRadialGradient(x, floor, 10, x, floor, r * 1.3);
  p.addColorStop(0, `rgba(${col},${0.45 * a})`); p.addColorStop(1, `rgba(${col},0)`);
  c.fillStyle = p; c.beginPath(); c.ellipse(x, floor, r * 1.3, r * 0.3, 0, 0, Math.PI * 2); c.fill();
  c.restore();
  // armatür
  c.fillStyle = "#1A1C20"; rr(c, x - 46, top - 40, 92, 46, 8); c.fill();
  c.fillStyle = `rgba(${col},${0.9 * a})`; c.beginPath(); c.ellipse(x, top + 4, 34, 8, 0, 0, Math.PI * 2); c.fill();
}

/** Pano figür ikonu (100 kişilik ızgaralar). lit: sarı el kaldırma, tired: çöküş (gri) */
export function figureIcon(c: Ctx, x: number, y: number, s: number, lit: number, tired: number) {
  c.save(); c.translate(x, y); c.scale(s, s);
  const droop = ease.inOut(clamp(tired));
  const col = lit > 0 ? `rgb(${lerp(110, lerp(242, 120, droop), lit)},${lerp(122, lerp(207, 132, droop), lit)},${lerp(140, lerp(58, 150, droop), lit)})` : "#5B6678";
  c.fillStyle = col; c.strokeStyle = col; c.lineCap = "round";
  c.rotate(droop * 0.18);
  c.beginPath(); c.arc(droop * 6, -40 + droop * 10, 9, 0, Math.PI * 2); c.fill();
  rr(c, -10, -28 + droop * 6, 20, 30 - droop * 4, 7); c.fill();
  c.lineWidth = 5;
  const up = ease.out(clamp(lit)) * (1 - droop);
  c.beginPath(); c.moveTo(8, -24 + droop * 6); c.lineTo(lerp(14, 16, up), lerp(-6, -52, up) + droop * 14); c.stroke();
  c.beginPath(); c.moveTo(-8, -24 + droop * 6); c.lineTo(-14, -6 + droop * 4); c.stroke();
  c.restore();
}
void C;
