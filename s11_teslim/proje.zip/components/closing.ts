// s11 kapanış parçaları: göz merceği, ay takvimi, hayat pencereleri (ofis / ev / kafe)
import { W, H, clamp, lerp, rnd, ease } from "../engine/core";
import { C, font, lightPool, rr } from "../design/style";
import { drawPerson } from "../characters/people";
import { mug, plant } from "../characters/props";
import { officeDesk } from "../design/env";
type Ctx = CanvasRenderingContext2D;

/** Göz merceği: open 0..1 (kapak), grey 0..1 (solma), look -1..1 */
export function eyeLens(c: Ctx, t: number, x: number, y: number, s: number, o: { open?: number; grey?: number; look?: number; scan?: number } = {}) {
  const op = clamp(o.open ?? 1), gr = clamp(o.grey ?? 0), lk = o.look ?? 0;
  c.save(); c.translate(x, y); c.scale(s, s);
  // pirinç halka (mercek gövdesi)
  c.fillStyle = "rgba(0,0,0,0.45)"; c.beginPath(); c.ellipse(10, 14, 250, 160, 0, 0, Math.PI * 2); c.fill();
  const rg = c.createLinearGradient(-240, -150, 240, 150); rg.addColorStop(0, "#8A7448"); rg.addColorStop(1, "#4A3C24");
  c.fillStyle = rg; c.beginPath(); c.ellipse(0, 0, 240, 150, 0, 0, Math.PI * 2); c.fill();
  c.save(); c.beginPath(); c.ellipse(0, 0, 214, 128 * op, 0, 0, Math.PI * 2); c.clip();
  c.fillStyle = "#E4DED2"; c.fillRect(-240, -150, 480, 300);
  const ix = lk * 60 + Math.sin(t * 0.7) * 6;
  const ig = c.createRadialGradient(ix, 0, 10, ix, 0, 92);
  ig.addColorStop(0, gr > 0.5 ? "#4A4E56" : "#2A4A5E"); ig.addColorStop(0.7, gr > 0.5 ? "#6A6E76" : "#3E6A7E"); ig.addColorStop(1, "#1A1E24");
  c.fillStyle = ig; c.beginPath(); c.arc(ix, 0, 92, 0, Math.PI * 2); c.fill();
  c.fillStyle = "#07090C"; c.beginPath(); c.arc(ix, 0, 38, 0, Math.PI * 2); c.fill();
  c.fillStyle = "rgba(255,255,255,0.7)"; c.beginPath(); c.arc(ix - 30, -30, 14, 0, Math.PI * 2); c.fill();
  if (gr > 0) { c.fillStyle = `rgba(40,44,50,${gr * 0.55})`; c.fillRect(-240, -150, 480, 300); }
  // tarama çizgisi (bakış)
  const sc = o.scan ?? 0;
  if (sc > 0) { c.fillStyle = `rgba(190,215,240,${0.18 * sc})`; c.fillRect(-240 + ((t * 260) % 480), -150, 26, 300); }
  c.restore();
  // kapaklar
  c.fillStyle = "#3A2E22";
  c.beginPath(); c.ellipse(0, 0, 216, 130, 0, Math.PI, Math.PI * 2); c.ellipse(0, 0, 216, 130 * op, 0, 0, Math.PI, true); c.fill();
  c.beginPath(); c.ellipse(0, 0, 216, 130, 0, 0, Math.PI); c.ellipse(0, 0, 216, 130 * op, 0, Math.PI, 0, true); c.fill();
  c.strokeStyle = "#B89A5E"; c.lineWidth = 6; c.beginPath(); c.ellipse(0, 0, 240, 150, 0, 0, Math.PI * 2); c.stroke();
  c.restore();
}

/** Ay takvimi (31 gün). ev(i): olay türü 0 yok / 1 alev / 2 ✓. lit: olaylı günler sarı, fade: boş günler söner, dust: boş günler dağılır */
export function monthGrid(c: Ctx, t: number, x: number, y: number, s: number, o: { ev: (i: number) => number; pop?: (i: number) => number; lit?: number; fade?: number; dust?: number }) {
  const lit = o.lit ?? 0, fade = clamp(o.fade ?? 0), du = clamp(o.dust ?? 0);
  c.save(); c.translate(x, y); c.scale(s, s);
  // kağıt arka
  c.fillStyle = "rgba(0,0,0,0.5)"; c.fillRect(-640, -400, 1300, 820);
  c.fillStyle = "#D6D0C2"; c.fillRect(-650, -410, 1300, 820);
  c.fillStyle = "#7A2E2A"; c.fillRect(-650, -410, 1300, 90);
  c.fillStyle = "#F0E8DA"; c.font = font(700, 52, true); c.textAlign = "center"; c.fillText("5月", 0, -346);
  for (let r = 0; r < 2; r++) { c.fillStyle = "#2A2A2A"; c.beginPath(); c.arc(-420 + r * 840, -410, 16, 0, Math.PI * 2); c.fill(); }
  const days = "日月火水木金土";
  c.font = font(500, 24); c.fillStyle = "rgba(26,29,36,0.6)";
  for (let d = 0; d < 7; d++) c.fillText(days[d], -540 + d * 180, -284);
  for (let i = 0; i < 31; i++) {
    const col = (i + 5) % 7, row = Math.floor((i + 5) / 7);
    const cx = -540 + col * 180, cy = -210 + row * 128;
    const e = o.ev(i), pop = o.pop ? clamp(o.pop(i)) : 1;
    let a = 1, dy = 0, rot = 0;
    if (!e) { a = 1 - fade * 0.75; const k = clamp(du * 1.6 - rnd(i, 3) * 0.6); a *= 1 - k; dy = k * (60 + rnd(i, 4) * 80); rot = k * (rnd(i, 5) - 0.5) * 0.8; }
    if (a <= 0.01) {
      continue;
    }
    c.save(); c.translate(cx, cy + dy); c.rotate(rot); c.globalAlpha *= a;
    if (e && lit > 0) lightPool(c, 0, 0, 120, "rgba(242,207,58,", 0.35 * lit);
    c.fillStyle = e ? `rgb(${lerp(236, 248, lit)},${lerp(230, 222, lit)},${lerp(218, 150, lit)})` : "#ECE6D8";
    rr(c, -80, -54, 160, 108, 8); c.fill();
    c.strokeStyle = e && lit > 0.3 ? C.yellowDeep : "rgba(26,29,36,0.15)"; c.lineWidth = 3; rr(c, -80, -54, 160, 108, 8); c.stroke();
    c.fillStyle = col === 0 ? "#9A3A30" : "rgba(26,29,36,0.75)"; c.font = font(600, 28); c.textAlign = "left"; c.fillText(String(i + 1), -68, -20);
    if (e) {
      c.globalAlpha *= pop; c.textAlign = "center"; c.font = font(700, 40);
      if (e === 1) { c.fillStyle = C.alarm; c.beginPath(); c.moveTo(20, 40); c.quadraticCurveTo(-8, 18 + Math.sin(t * 9 + i) * 3, 20, -16); c.quadraticCurveTo(48, 18, 20, 40); c.fill(); }
      else { c.fillStyle = "#2F7A4A"; c.fillText("✓", 22, 34); }
    }
    c.restore();
  }
  c.restore();
}

/** Hayat penceresi: cephedeki aydınlık oda. kind 0 ofis / 1 ev / 2 kafe. glow: sessiz kişinin sarı halesi */
export function lifeWindow(c: Ctx, t: number, x: number, y: number, kind: number, o: { glow?: number; light?: number; act?: number } = {}) {
  const w = 560, h = 360, gl = o.glow ?? 0, L = o.light ?? 1;
  c.save(); c.translate(x, y);
  c.save(); c.beginPath(); c.rect(-w / 2, -h / 2, w, h); c.clip();
  const bg = [["#2A3644", "#3E4C5A"], ["#4A3A2C", "#6A5440"], ["#3E2E24", "#5E4434"]][kind];
  const g = c.createLinearGradient(0, -h / 2, 0, h / 2); g.addColorStop(0, bg[0]); g.addColorStop(1, bg[1]);
  c.fillStyle = g; c.fillRect(-w / 2, -h / 2, w, h);
  c.globalAlpha *= L;
  if (kind === 0) {
    for (let k = 0; k < 4; k++) { c.fillStyle = "#1E2630"; c.fillRect(-250 + k * 130, -150, 100, 70); c.fillStyle = "rgba(150,200,240,0.18)"; c.fillRect(-244 + k * 130, -144, 88, 58); }
    c.fillStyle = "rgba(255,240,210,0.5)"; c.fillRect(-w / 2, -h / 2, w, 8);
    drawPerson(c, -150, 170, 0.42, { outfit: 0, pose: "stand", facing: 0.4, armUp: 0.3 + 0.2 * Math.sin(t * 3), rim: 0.5 });
    drawPerson(c, 120, 150, 0.4, { outfit: 2, pose: "desk", facing: -0.2, glow: gl, rim: 0.4, bob: Math.sin(t * 1.6) });
    officeDesk(c, 120, 168, 0.36, 0.7, 0.6);
  } else if (kind === 1) {
    // ev: çamaşır ipi, sofra, kişi çamaşır katlar
    c.strokeStyle = "rgba(220,210,190,0.5)"; c.lineWidth = 2; c.beginPath(); c.moveTo(-270, -110); c.quadraticCurveTo(0, -80, 270, -110); c.stroke();
    ["#C9B89A", "#5A6B8A", "#E0DCD2", "#8A3A40"].forEach((col, n) => { c.fillStyle = col; c.save(); c.translate(-180 + n * 110, -96 + Math.sin(n) * 4); c.rotate(Math.sin(t * 1.2 + n) * 0.05); c.fillRect(-26, 0, 52, 60); c.restore(); });
    c.fillStyle = "#5E4030"; c.fillRect(-260, 110, 300, 18);
    lightPool(c, -100, -60, 260, "rgba(255,200,130,", 0.2);
    drawPerson(c, 150, 170, 0.42, { outfit: 3, pose: "stand", facing: -0.3, armUp: 0.25 + 0.1 * Math.sin(t * 4), glow: gl, rim: 0.5 });
    drawPerson(c, -120, 160, 0.38, { outfit: 1, pose: "sit", facing: 0.3, rim: 0.4 });
    for (let n = 0; n < 3; n++) { c.fillStyle = ["#E0DCD2", "#5A6B8A", "#C9B89A"][n]; rr(c, 200, 120 - n * 10 - (o.act ?? 0) * (n === 2 ? 10 : 0), 70, 10, 3); c.fill(); }
  } else {
    // kafe: masa, iki fincan, sarkık lamba, iki arkadaş — biri konuşur, biri dinler
    c.strokeStyle = "#1A1410"; c.lineWidth = 3; c.beginPath(); c.moveTo(0, -h / 2); c.lineTo(0, -110); c.stroke();
    c.fillStyle = "#C98A3A"; c.beginPath(); c.moveTo(-40, -80); c.lineTo(40, -80); c.lineTo(20, -110); c.lineTo(-20, -110); c.fill();
    lightPool(c, 0, -20, 260, "rgba(255,190,110,", 0.3);
    for (let k = 0; k < 5; k++) { c.fillStyle = "#2A1E16"; c.fillRect(-260 + k * 22, -150, 14, 60); }
    plant(c, t, 230, 130, 0.4);
    drawPerson(c, -130, 170, 0.42, { outfit: 5, pose: "sit", facing: 0.6, armUp: 0.3 + 0.25 * Math.max(0, Math.sin(t * 3)), rim: 0.5 });
    drawPerson(c, 130, 170, 0.42, { outfit: 2, pose: "sit", facing: -0.6, glow: gl, rim: 0.5, bob: Math.sin(t * 1.3) * 1.5 });
    c.fillStyle = "#4A3020"; rr(c, -120, 90, 240, 16, 4); c.fill();
    mug(c, t, -40, 90, 0.4, 0.8); mug(c, t, 50, 90, 0.4, 0.8);
  }
  if (gl > 0) { c.fillStyle = `rgba(242,207,58,${0.08 * gl})`; c.fillRect(-w / 2, -h / 2, w, h); }
  c.restore();
  // çerçeve + pervaz
  c.strokeStyle = "#1A1C20"; c.lineWidth = 18; c.strokeRect(-w / 2, -h / 2, w, h);
  c.lineWidth = 8; c.beginPath(); c.moveTo(0, -h / 2); c.lineTo(0, h / 2); c.stroke();
  c.fillStyle = "#2A2C30"; c.fillRect(-w / 2 - 20, h / 2 + 4, w + 40, 16);
  if (gl > 0) { c.strokeStyle = `rgba(242,207,58,${0.55 * gl})`; c.lineWidth = 4; c.strokeRect(-w / 2 - 12, -h / 2 - 12, w + 24, h + 24); }
  c.restore();
}

/** Gece cephesi: tuğla/beton duvar, karanlık pencereler, uzak şehir */
export function nightFacade(c: Ctx, t: number, pan = 0) {
  c.fillStyle = "#070A10"; c.fillRect(-2000, -1600, W + 4000, H + 3200);
  // gökyüzü + uzak bina silüetleri (parallax 0.3)
  c.save(); c.translate(-pan * 0.3, 0);
  for (let i = 0; i < 40; i++) { const bx = -1400 + i * 120, bh = 400 + rnd(i, 9) * 700; c.fillStyle = "#0C1220"; c.fillRect(bx, 1100 - bh, 110, bh + 900); for (let k = 0; k < 14; k++) if (rnd(i * 31 + k, 10) > 0.7) { c.fillStyle = "rgba(255,206,140,0.35)"; c.fillRect(bx + 10 + (k % 3) * 32, 1120 - bh + Math.floor(k / 3) * 60, 12, 16); } }
  c.restore();
  // ön bina cephesi
  c.fillStyle = "#1A1C22"; c.fillRect(-900, -560, 3700, 2200);
  for (let r = 0; r < 26; r++) { c.fillStyle = "rgba(255,255,255,0.025)"; c.fillRect(-900, -560 + r * 86, 3700, 3); }
  for (let i = 0; i < 9; i++) for (let r = 0; r < 4; r++) {
    const wx = -700 + i * 420, wy = -360 + r * 520;
    if (r === 1 && (i === 2 || i === 4 || i === 6)) continue;
    c.fillStyle = "#0E1118"; c.fillRect(wx - 150, wy - 100, 300, 200);
    if (rnd(i * 7 + r, 12) > 0.75) { c.fillStyle = "rgba(255,200,130,0.12)"; c.fillRect(wx - 140, wy - 90, 280, 180); }
  }
}
void W; void H; void ease;
