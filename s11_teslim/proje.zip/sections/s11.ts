// s11 何も起きなかった日 — ses 22  (s10 yapısı: SCENES + lens + cues)
// Yeni ortak parçalar: components/closing.ts → eyeLens(), monthGrid(), lifeWindow(), nightFacade()
// ★ Kapanış ayracı: s01 açılışıyla aynı kompozisyon (envNightRoom + deskProps + geppoSheet @ 930,800); kağıdın arkasındaki kişi bu kez görünür
import { Section, Part, Cue, W, H, clamp, ease, prog, lerp, rnd, win, speaking } from "../engine/core";
import { C, font, lightPool, lightCone, fadeBlack, rr, dust } from "../design/style";
import { lens, cam, dof, Lens, bokeh } from "../design/grade";
import { envNightRoom, deskProps, officeDesk } from "../design/env";
import { whipStreaks } from "../design/fx";
import { drawPerson } from "../characters/people";
import { drawMascot } from "../characters/mascot";
import { sectionTitle, geppoSheet, memoryCard } from "../components/cards";
import { armchair } from "../components/evaluation";
import { gazeBeam } from "../components/evaluator";
import { drawerCabinet } from "../components/memory";
import { eyeLens, monthGrid, lifeWindow, nightFacade } from "../components/closing";
import { drawSubtitles } from "../components/subtitle";
import t22 from "../timing/22.json";

const P22: Part = { timing: t22 as any, at: 3.4 };
const parts = [P22];
const j = (l: number) => P22.at + l;
const END = j(40.4);
const QUESTION = j(33.3); // son soru: beyaz yazı (altyazı yerine)
type Ctx = CanvasRenderingContext2D;

function layer(ctx: Ctx, a: number, fn: () => void) {
  if (a <= 0.001) return;
  ctx.save(); ctx.globalAlpha *= clamp(a); fn(); ctx.restore();
}
const breathe = (t: number, k = 0) => Math.sin(t * 1.6 + k * 1.3) * 2;
function blinkAt(t: number) { const ph = (t % 4.7) / 4.7; return ph > 0.96 ? Math.sin(((ph - 0.96) / 0.04) * Math.PI) : 0; }
function label(c: Ctx, x: number, y: number, txt: string, a: number, col: string = C.text, size = 50, align: CanvasTextAlign = "center") {
  layer(c, a, () => { c.font = font(700, size, true); c.textAlign = align; c.fillStyle = col; c.fillText(txt, x, y); });
}
/** el yazısı gibi soldan açılan metin */
function writeText(c: Ctx, x: number, y: number, txt: string, k: number, size: number, col: string, weight = 700) {
  if (k <= 0) return;
  c.save(); c.font = font(weight, size, true); c.textAlign = "left";
  const w = c.measureText(txt).width;
  c.beginPath(); c.rect(x - w / 2 - 10, y - size * 1.2, (w + 20) * clamp(k), size * 1.6); c.clip();
  c.fillStyle = col; c.fillText(txt, x - w / 2, y); c.restore();
}

const LENS_OBS: Lens = { shadow: "rgba(12,30,46,0.42)", high: "rgba(255,200,130,0.08)", bloom: 0.5, ca: 1.0, vig: 0.88, grain: 0.07, exposure: 0.95, sat: 0.8 };
const LENS_DOC: Lens = { shadow: "rgba(20,40,58,0.3)", high: "rgba(255,200,140,0.06)", bloom: 0.45, ca: 0.4, vig: 0.72, grain: 0.055, exposure: 1.0, sat: 0.85 };
const LENS_CITY: Lens = { shadow: "rgba(14,30,52,0.42)", high: "rgba(255,190,120,0.14)", bloom: 0.75, ca: 0.9, vig: 0.84, grain: 0.07, exposure: 0.98, sat: 0.9 };
const LENS_DESK: Lens = { shadow: "rgba(18,52,66,0.34)", high: "rgba(255,170,90,0.12)", bloom: 0.6, ca: 0.6, vig: 0.8, grain: 0.065, exposure: 0.98, sat: 0.9 };

// ================= A: 評価する人が、悪いわけではない — gözlem odası =================
function sceneObs(c: Ctx, t: number) {
  const l = t - P22.at;
  const k = ease.inOut(prog(l, -3.4, 3.4));
  const warm = ease.out(prog(l, 1.3, 2.2));          // 悪いわけでは: sıcak ışık arkadan sarar
  const rack = ease.inOut(prog(l, 0.4, 1.2));
  c.save();
  cam(c, t, lerp(1.08, 1.2, k), lerp(60, -40, k), lerp(-10, 10, k), 0.4, 960, 600);
  // tek yönlü cam + karşı oda (bulanık)
  c.fillStyle = "#0A0D12"; c.fillRect(-400, -300, W + 800, H + 600);
  dof(c, lerp(1, 5, rack), () => {
    c.fillStyle = "#16202C"; c.fillRect(260, 140, 1400, 520);
    lightCone(c, 1260, 140, Math.PI / 2, 0.35, 520, 0.22, "220,230,250");
    armchair(c, 1260, 620, 0.7, { col: "#3A3632" });
    drawPerson(c, 1260, 610, 0.62, { outfit: 2, pose: "sit", shade: 0.4, rim: 0.6, facing: 0.1, bob: breathe(t) * 0.3 });
    for (let m = 0; m < 3; m++) { c.fillStyle = "rgba(200,220,240,0.05)"; c.beginPath(); c.moveTo(400 + m * 420, 140); c.lineTo(520 + m * 420, 140); c.lineTo(400 + m * 420, 660); c.lineTo(280 + m * 420, 660); c.fill(); }
  });
  c.strokeStyle = "#20262E"; c.lineWidth = 22; c.strokeRect(260, 140, 1400, 520);
  // değerlendirici: arkadan, koltukta (ön plan, keskin)
  dof(c, lerp(4, 0, rack), () => {
    c.fillStyle = "#2A1E14"; c.fillRect(-400, 780, W + 800, 500);
    lightPool(c, 640, 760, 560, "rgba(255,206,140,", 0.12 + 0.18 * warm);
    armchair(c, 560, 1010, 1.15, { col: "#4A2E26", glow: 0.15 * warm });
    drawPerson(c, 560, 960, 1.05, { outfit: 4, pose: "sit", tie: true, rim: 0.4 + 0.5 * warm, rimSide: 1, facing: 0.3, bob: breathe(t, 1) * 0.5, shade: lerp(0.5, 0.2, warm) });
    gazeBeam(c, 600, 600, 1260, 470, 0.25 * (1 - warm * 0.5));
  });
  c.restore();
  label(c, 960, 120, "評価する人が、悪いわけではない", ease.out(prog(l, 1.4, 1.9)) * (1 - prog(l, 2.9, 3.3)), C.text, 46);
}

// ================= B: 人の目と記憶は、もともとそういうふうに =================
const MEM_EV = (i: number) => (i % 3 === 0 ? 1 : 0); // akan kartlar: her üçüncüsü olaylı
function sceneEyeMemory(c: Ctx, t: number) {
  const l = t - P22.at;
  const k = ease.inOut(prog(l, 3.0, 8.0));
  const eyeOpen = ease.out(prog(l, 3.6, 4.0));
  const drawer = ease.out(prog(l, 3.95, 4.5));
  c.save();
  cam(c, t, lerp(1.0, 1.08, k), lerp(-40, 40, k), 0, 0.35, 960, 540);
  c.fillStyle = "#101418"; c.fillRect(-400, -300, W + 800, H + 600);
  dof(c, 3, () => { bokeh(c, t, 10, 100, 900, 41, 0.18); for (let n = 0; n < 6; n++) { c.fillStyle = "rgba(255,255,255,0.025)"; c.fillRect(n * 340, 0, 3, H); } });
  c.fillStyle = "#2E2218"; c.fillRect(-400, 820, W + 800, 500);
  lightPool(c, 960, 700, 900, "rgba(255,214,150,", 0.14);
  eyeLens(c, t, 520, 470, 0.95, { open: eyeOpen, look: Math.sin(l * 1.2) * 0.6, scan: win(l, 4.0, 7.6) });
  label(c, 520, 720, "目", ease.out(prog(l, 3.7, 4.1)), C.text, 56);
  drawerCabinet(c, 1420, 880, 0.82, { t, cols: 2, rows: 3, open: (i) => (i === 2 ? drawer * 0.9 : 0), cards: (i) => (i === 2 ? 5 : 2), glow: (i) => (i === 2 ? 0.6 * drawer : 0.1), labels: () => "記憶" });
  label(c, 1420, 200, "記憶", ease.out(prog(l, 3.95, 4.4)), C.text, 56);
  // gözden çekmeceye akan günler: olaylılar girer (sarı), olaysızlar düşüp yerde kaybolur
  for (let n = 0; n < 9; n++) {
    const s0 = 4.4 + n * 0.32, p = prog(l, s0, s0 + 1.3);
    if (p <= 0 || p >= 1) continue;
    const ev = MEM_EV(n);
    const x = lerp(700, 1380, ease.inOut(p));
    const y = ev ? lerp(470, 560, ease.inOut(p)) - Math.sin(p * Math.PI) * 120 : lerp(470, 470, p) + Math.pow(Math.max(0, p - 0.45) * 1.8, 2) * 420;
    const a = ev ? 1 - prog(p, 0.85, 1) : 1 - prog(p, 0.7, 1);
    memoryCard(c, x, y, 0.42, { label: ev ? "トラブル対応" : "", glow: ev ? 0.8 : 0, rot: (rnd(n, 3) - 0.5) * 0.4 + (ev ? 0 : p * 0.6), alpha: a, who: "none", fade: ev ? 0 : 0.6 });
  }
  c.restore();
  label(c, 960, 120, "もともと、そういうふうにできている", ease.out(prog(l, 5.0, 5.5)) * (1 - prog(l, 7.3, 7.7)), C.mist, 44);
}

// ================= C: 評価は、目ではなく、記憶で行われる。 (tez) =================
function sceneThesis(c: Ctx, t: number) {
  const l = t - P22.at;
  const k = ease.inOut(prog(l, 7.5, 11.8));
  const notEye = ease.out(prog(l, 8.8, 9.3));
  const mem = ease.out(prog(l, 9.96, 10.5));
  c.save();
  cam(c, t, lerp(1.12, 1.0, k), lerp(0, 0, k), lerp(-20, 20, k), 0.25, 960, 540);
  c.fillStyle = "#0C0F14"; c.fillRect(-400, -300, W + 800, H + 600);
  // masa üstü: tez kartı (kâğıt), iki yanda göz (söner) ve çekmece (yanar)
  const tg = c.createLinearGradient(0, 640, 0, H); tg.addColorStop(0, "#3A2A1C"); tg.addColorStop(1, "#140E09");
  c.fillStyle = tg; c.fillRect(-400, 640, W + 800, 700);
  lightCone(c, 960, -40, Math.PI / 2, 0.4, 900, 0.2, "255,226,170");
  dof(c, 2.5, () => {
    eyeLens(c, t, 300, 560, 0.55, { open: 1 - notEye * 0.55, grey: notEye, look: 0.4 });
    drawerCabinet(c, 1640, 860, 0.5, { t, cols: 2, rows: 3, open: (i) => (i === 2 ? 0.8 : 0), cards: () => 4, glow: (i) => (i === 2 ? mem : 0.1 * mem), labels: () => "記憶" });
  });
  if (mem > 0) lightPool(c, 1640, 640, 360, "rgba(242,207,58,", 0.3 * mem);
  c.save(); c.translate(960, 520); c.rotate(-0.015);
  c.fillStyle = "rgba(0,0,0,0.5)"; c.fillRect(-560 + 16, -150 + 20, 1120, 300);
  c.fillStyle = "#DCD6C8"; c.fillRect(-560, -150, 1120, 300);
  writeText(c, 0, -30, "評価は、目ではなく、", prog(l, 7.9, 9.3), 74, C.ink);
  writeText(c, 0, 90, "記憶で行われる。", prog(l, 9.96, 10.8), 82, "#1B2A4A", 800);
  // 目 üstü gri çizgi / 記憶 altı sarı fosforlu kalem
  if (notEye > 0) { c.strokeStyle = "rgba(90,96,108,0.8)"; c.lineWidth = 6; c.beginPath(); c.moveTo(-34, -52); c.lineTo(-34 + 230 * notEye, -52); c.stroke(); }
  if (mem > 0) { c.fillStyle = "rgba(242,207,58,0.45)"; c.fillRect(-330, 98, 220 * mem, 22); }
  c.restore();
  c.restore();
}

// ================= D: 記憶には、何も起きなかった日が残りません =================
const DAY_EV = (i: number) => ([2, 8, 13, 19, 26].includes(i) ? (i % 2 ? 2 : 1) : 0);
function sceneMonth(c: Ctx, t: number) {
  const l = t - P22.at;
  const k = ease.inOut(prog(l, 11.4, 16.4));
  const lit = ease.out(prog(l, 12.0, 12.8));
  const fade = ease.inOut(prog(l, 13.3, 14.4));
  const du = ease.in(prog(l, 14.56, 15.9));
  c.save();
  cam(c, t, lerp(0.86, 1.0, k), lerp(30, -30, k), lerp(30, -10, k), 0.3, 960, 540);
  c.fillStyle = "#11141A"; c.fillRect(-500, -400, W + 1000, H + 800);
  // mantar pano dokusu
  for (let n = 0; n < 220; n++) { c.fillStyle = `rgba(150,110,70,${0.06 + rnd(n, 1) * 0.06})`; c.fillRect(rnd(n, 2) * W * 1.4 - 300, rnd(n, 3) * H * 1.4 - 200, 4, 4); }
  lightPool(c, 960, 500, 900, "rgba(255,220,170,", 0.14);
  monthGrid(c, t, 960, 560, 0.78, { ev: DAY_EV, pop: (i) => prog(l, 11.6 + (i % 5) * 0.08, 12.1 + (i % 5) * 0.08), lit, fade, dust: du });
  // olaylı günler hafıza kartına dönüşüp yukarı uçar
  [2, 8, 13, 19, 26].forEach((d, n) => {
    const p = ease.inOut(prog(l, 12.3 + n * 0.12, 13.4 + n * 0.12));
    if (p <= 0) return;
    const col = (d + 5) % 7, row = Math.floor((d + 5) / 7);
    const x0 = 960 + (-540 + col * 180) * 0.78, y0 = 560 + (-210 + row * 128) * 0.78;
    memoryCard(c, lerp(x0, 1700 - n * 30, p), lerp(y0, 150 + n * 22, p), lerp(0.3, 0.26, p), { label: DAY_EV(d) === 1 ? "火事" : "解決", glow: 0.8, rot: (n - 2) * 0.06, alpha: 1 - prog(l, 15.6, 16.2), who: "none" });
  });
  // toz: dağılan boş günler
  if (du > 0) for (let n = 0; n < 60; n++) { const p = clamp(du * 1.3 - rnd(n, 7) * 0.3); c.fillStyle = `rgba(220,214,200,${0.3 * (1 - p)})`; c.fillRect(300 + rnd(n, 8) * 1320 + Math.sin(n + t) * 10, 300 + rnd(n, 9) * 500 + p * 200, 4, 4); }
  c.restore();
  label(c, 960, 110, "何も起きなかった日", ease.out(prog(l, 13.3, 13.8)) * (1 - prog(l, 15.6, 16.0)), C.mist, 50);
}

// ================= E: 職場 → 家 → 友人: 一続きの引き (cephe) =================
const WX = [140, 980, 1820], WY = 160;
function sceneCity(c: Ctx, t: number) {
  const l = t - P22.at;
  // kamera yolu: ofis penceresi içinden (zoom 3) → geri çekil → eve pan → kafeye pan → tümü
  const pull = ease.inOut(prog(l, 16.6, 18.8));
  const toHome = ease.inOut(prog(l, 18.9, 19.9));
  const toCafe = ease.inOut(prog(l, 20.3, 21.3));
  const wide = ease.inOut(prog(l, 22.0, 24.8));
  let fx = lerp(WX[0], WX[1], toHome); fx = lerp(fx, WX[2], toCafe); fx = lerp(fx, WX[1], wide);
  const z = lerp(lerp(3.1, 1.25, pull), 0.62, wide);
  const fy = lerp(WY, WY + 140, wide);
  const g0 = ease.out(prog(l, 17.2, 17.9)), g1 = ease.out(prog(l, 19.6, 20.3)), g2 = ease.out(prog(l, 21.0, 21.7));
  const sup = ease.out(prog(l, 24.44, 25.1));
  c.save();
  c.translate(W / 2, H / 2); c.scale(z, z); c.translate(-fx, -fy);
  c.translate(Math.sin(t * 0.7) * 3, Math.cos(t * 0.5) * 2);
  nightFacade(c, t, fx - WX[1]);
  // pencereler
  lifeWindow(c, t, WX[0], WY, 0, { glow: Math.max(g0 * 0.8, sup), act: 0 });
  lifeWindow(c, t, WX[1], WY, 1, { glow: Math.max(g1 * 0.8, sup), act: prog(l, 19.8, 20.2) });
  lifeWindow(c, t, WX[2], WY, 2, { glow: Math.max(g2 * 0.8, sup) });
  // 支えている: üç pencere arası ince sarı ip
  if (sup > 0) { c.strokeStyle = `rgba(242,207,58,${0.35 * sup})`; c.lineWidth = 4; c.setLineDash([10, 14]); c.beginPath(); c.moveTo(WX[0] + 280, WY + 120); c.quadraticCurveTo(560, WY + 260, WX[1] - 280, WY + 120); c.moveTo(WX[1] + 280, WY + 120); c.quadraticCurveTo(1400, WY + 260, WX[2] - 280, WY + 120); c.stroke(); c.setLineDash([]); }
  // sokak: yağmur ıslaklığı, geçen araba ışıkları
  c.fillStyle = "#0B0D12"; c.fillRect(-2000, 1180, W + 4000, 1400);
  for (let n = 0; n < 3; n++) { const cx = ((t * 520 + n * 1400) % 4600) - 1600; lightPool(c, cx, 1240, 260, "rgba(255,220,170,", 0.25); c.fillStyle = "rgba(255,90,70,0.6)"; c.fillRect(cx - 120, 1225, 18, 8); }
  c.restore();
  // ön plan: geçen tren (karanlık bant + aydınlık pencereler) — 家→友人 arası görsel olay
  const tr = prog(l, 21.6, 23.2);
  if (tr > 0 && tr < 1) {
    const ox = lerp(W + 200, -3200, tr);
    c.fillStyle = "rgba(6,8,12,0.92)"; c.fillRect(ox, 790, 3000, 110);
    for (let n = 0; n < 22; n++) { c.fillStyle = "rgba(255,226,170,0.35)"; c.fillRect(ox + 40 + n * 135, 812, 90, 46); }
    whipStreaks(c, Math.sin(Math.PI * tr) * 0.5, -1, 21);
  }
  label(c, 960, 110, "職場だけの話ではない", ease.out(prog(l, 16.9, 17.4)) * (1 - prog(l, 18.9, 19.3)), C.text, 46);
  label(c, 960, 110, "家の中にも", ease.out(prog(l, 19.5, 19.9)) * (1 - prog(l, 20.4, 20.7)), C.text, 46);
  label(c, 960, 110, "友人とのあいだにも", ease.out(prog(l, 20.7, 21.1)) * (1 - prog(l, 21.9, 22.3)), C.text, 46);
  label(c, 960, 110, "静かに、支えている誰か", ease.out(prog(l, 24.1, 24.6)) * (1 - prog(l, 26.2, 26.6)), C.yellow, 52);
}

// ================= F: ★ 月報「特になし」 — s01 ile aynı kompozisyon, arkadaki人 görünür =================
function sceneGeppo(c: Ctx, t: number) {
  const l = t - P22.at;
  const k = ease.inOut(prog(l, 26.2, 33.4));
  const through = ease.inOut(prog(l, 29.8, 31.0));
  const seen = ease.out(prog(l, 30.4, 31.6));        // bu kez: kişi başını kaldırır, tam görünür
  const lampOff = ease.inOut(prog(l, 35.9, 36.6));
  const pull = ease.inOut(prog(l, 33.2, 36.0));
  c.save();
  cam(c, t, lerp(1.0, 1.2, k) + 0.3 * through - 0.25 * pull, lerp(60, -40, k), lerp(-30, -90, k) - 300 * through + 260 * pull, 0.6);
  envNightRoom(c, t, lerp(2, 5, k));
  deskProps(c, t);
  c.save();
  c.translate(930, 800); c.rotate(-0.06); c.transform(1, 0, -0.08, 0.82, 0, 0);
  layer(c, through, () => {
    c.save();
    c.beginPath(); c.rect(-258, -340, 516, 680); c.clip();
    c.fillStyle = "#151A22"; c.fillRect(-260, -340, 520, 680);
    bokeh(c, t, 6, -300, -60, 31, 0.25);
    lightPool(c, 10, -20, 300, "rgba(242,207,58,", 0.25 * seen);
    drawPerson(c, 10, 150, 1.0, { pose: "sit", outfit: 1, rim: 0.9, rimSide: -1, glow: 0.7 + 0.5 * seen, facing: lerp(-0.4, 0, seen), eye: seen > 0.5 ? 1 : 0, bob: breathe(t) - seen * 6 });
    officeDesk(c, 10, 162, 0.85, 0.6, 1);
    c.restore();
  });
  geppoSheet(c, 0, 0, 0.92, { write: 1, through: through * 0.97 });
  // 「特になし」 vurgusu: el yazısının üstünde sarı nefes
  const hi = win(l, 27.86, 29.9, 0.3);
  if (hi > 0) { c.fillStyle = `rgba(242,207,58,${0.3 * hi})`; c.fillRect(-210, 80, 240, 34); }
  c.restore();
  c.restore();
  fadeBlack(c, lampOff * 0.9);
  label(c, 960, 120, "月報の「特になし」", ease.out(prog(l, 27.0, 27.5)) * (1 - prog(l, 29.4, 29.8)), C.mist, 46);
  label(c, 960, 120, "その裏にいる人", ease.out(prog(l, 30.0, 30.5)) * (1 - prog(l, 32.6, 33.0)), C.yellow, 52);
  // マスコット: s01 のように端から, 静かに見守る
  layer(c, win(l, 31.0, 34.6, 0.5) * (1 - lampOff), () => drawMascot(c, 250, 1080, 0.7, { mouth: speaking(parts, t) * 0.3, lookX: 0.8, blink: blinkAt(t), light: 0.5, rim: 0.8, armR: 0.2 }));
  // 最後の問い: 白い文字、暗闇の中で消える
  const qa = ease.out(prog(l, 33.42, 34.2)) * (1 - ease.inOut(prog(l, 38.2, 39.6)));
  layer(c, qa, () => {
    c.textAlign = "center"; c.fillStyle = "#F2F3F5";
    c.shadowColor = "rgba(0,0,0,0.8)"; c.shadowBlur = 24;
    c.font = font(600, 72, true);
    c.fillText("自分は、誰を見ていないだろう。", 960, 560);
    c.shadowBlur = 0;
  });
  dust(c, t, 40, 0.18 * (1 - lampOff), 51);
}

// ================= ÇİZİM =================
const SCENES: [number, number, (c: Ctx, t: number) => void, Lens][] = [
  [0, j(3.4), sceneObs, LENS_OBS],
  [j(3.0), j(7.9), sceneEyeMemory, LENS_DOC],
  [j(7.5), j(11.7), sceneThesis, LENS_DOC],
  [j(11.4), j(16.4), sceneMonth, LENS_DOC],
  [j(16.0), j(26.8), sceneCity, LENS_CITY],
  [j(26.3), END, sceneGeppo, LENS_DESK],
];
const HARD = new Set<any>([sceneObs, sceneMonth]); // siyahtan / whip-pan girişli

function draw(ctx: Ctx, t: number) {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H);
  const active = SCENES.filter(([a, b]) => t >= a && t <= b);
  const L = active.length ? active[active.length - 1][3] : LENS_OBS;
  if (active.length) {
    lens(ctx, t, L, (c) => {
      for (const [a, , fn] of active) layer(c, HARD.has(fn) ? 1 : ease.sine(prog(t, a, a + 0.6)), () => fn(c, t));
    });
  }
  whipStreaks(ctx, Math.sin(Math.PI * prog(t, j(11.2), j(11.9))), 1, 31);
  sectionTitle(ctx, t, 0.0, 3.6, "11", "何も起きなかった日");
  if (t < QUESTION) drawSubtitles(ctx, parts, t);
  fadeBlack(ctx, 1 - prog(t, 0, 0.5));
  fadeBlack(ctx, prog(t, END - 1.0, END - 0.1));
}

// ================= SES EFEKTLERİ (eyleme bire bir) =================
const cues: Cue[] = [];
const cue = (t: number, type: string, gain = 1, p: Record<string, number> = {}) => cues.push({ t, type, gain, p });

cue(0.0, "room", 0.5, { d: END });
cue(0.35, "whoosh", 0.5, { d: 1.2 });                              // başlık (geçiş)
cue(j(0.3), "chair", 0.35);                                        // değerlendirici koltukta kıpırdar
cue(j(1.3), "lamp", 0.35);                                         // 悪いわけでは: sıcak ışık
cue(j(3.0), "swish", 0.3, { d: 0.9 });                             // göz/hafıza sahnesine (geçiş)
cue(j(3.6), "eyelid", 0.5);                                        // göz kapağı açılır
cue(j(3.95), "drawer", 0.5);                                       // 記憶 çekmecesi açılır
for (let n = 0; n < 9; n++) cue(j(4.4 + n * 0.32 + 1.1), MEM_EV(n) ? "cardrise" : "paper", MEM_EV(n) ? 0.25 : 0.15); // kart girer / düşer
cue(j(7.9), "pen", 0.45, { d: 1.3 });                              // tez yazılır
cue(j(8.8), "strike", 0.4);                                        // 目ではなく: gri çizgi
cue(j(8.9), "eyelid", 0.25);                                       // göz yarı kapanır
cue(j(9.96), "pen", 0.5, { d: 0.8 });                              // 記憶で
cue(j(10.0), "glowhum", 0.35, { d: 1.6 });                         // çekmece sarı
cue(j(10.4), "marker", 0.4);                                       // fosforlu kalem
cue(j(11.2), "whoosh", 0.7, { d: 0.8 });                           // whip-pan → takvim
cue(j(11.5), "pin", 0.4);                                          // takvim panoya
for (let n = 0; n < 5; n++) cue(j(11.6 + n * 0.08), "tileflip", 0.22); // olaylı günler belirir
cue(j(12.3), "cardrise", 0.3); cue(j(12.6), "cardrise", 0.25);     // günler hafızaya uçar
cue(j(13.3), "lowdrone", 0.3, { d: 1.6 });                         // 何も起きなかった日 söner
cue(j(14.56), "dissolve", 0.5);                                    // 残りません: toz
cue(j(16.0), "swish", 0.35, { d: 1.0 });                           // şehre (geçiş)
cue(j(16.2), "typing", 0.2, { d: 2.4 });                           // ofiste klavye
cue(j(17.2), "glowhum", 0.25, { d: 1.6 });                         // B sarı
cue(j(18.9), "swish", 0.25, { d: 1.0 });                           // pan → ev
cue(j(19.6), "rustle", 0.35);                                      // çamaşır katlanır
cue(j(19.9), "dishclink", 0.2);                                    // sofra
cue(j(20.6), "saucer", 0.4);                                       // kafe: fincan tabağa
cue(j(21.6), "train", 0.55, { d: 1.8 });                           // tren geçer
cue(j(24.4), "glowhum", 0.4, { d: 2.4 });                          // 支えている: üç pencere
cue(j(26.3), "whoosh", 0.3, { d: 1.0 });                           // masaya (geçiş)
cue(j(26.6), "bulbhum", 0.2, { d: 9.0 });                          // s01 masa lambası
cue(j(27.2), "paper", 0.35);                                       // 月報
cue(j(27.86), "marker", 0.3);                                      // 特になし vurgusu
cue(j(29.8), "heartbeat", 0.3, { d: 1.6 });                        // 裏に: kâğıt saydamlaşır
cue(j(30.4), "chair", 0.3);                                        // kişi başını kaldırır
cue(j(33.42), "lowdrone", 0.3, { d: 3.0 });                        // son soru
cue(j(35.9), "lampclick", 0.6);                                    // lamba söner
cue(END - 1.2, "whoosh", 0.2, { d: 1.2 });

void rr; void win;
export const s11: Section = { id: "s11", duration: END, parts, cues, draw };
